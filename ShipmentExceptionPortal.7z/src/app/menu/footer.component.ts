import { Component} from '@angular/core';
import { Router } from '@angular/router';

@Component({   
    selector: 'footerBar',
    templateUrl: './footer.component.html'
})

export class FooterBarComponent {
    constructor(private router: Router) {
            
    }    
}