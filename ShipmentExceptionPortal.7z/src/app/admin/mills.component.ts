import { OnInit, Component, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ShipmentExceptionService } from '../../services/ShipmentException.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'mills',
  templateUrl: './mills.component.html'
})
export class MillsComponent implements OnInit {
  items: any;
  @ViewChild('addMill') elMill: ElementRef;
  private route: ActivatedRoute;
  MillId:number;
  AddShowHide:boolean = true;
  EditShowHide:boolean = true;
  CreateShowHide:boolean = false;
  UpdateShowHide:boolean = false;  
  CancelShowHide = false;
  reverse: boolean = false;
  frmMill = new FormGroup({
    Millnumber: new FormControl('', [Validators.required, Validators.minLength(1)]),
    Millname: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'mill',
    itemsPerPage: 2,
    currentPage: 0,
    totalItems: 0,
  };

  param = {
    SortColumnName :"Millnumber",
    SortOrder :"ASC",
    PageSelected:0,
    PageSize:2
  }; 

  constructor(private renderer: Renderer2, private _ShipmentExceptionService: ShipmentExceptionService, private alertService : AlertService, private storage: StorageService) { 

  } 

  ngOnInit() {  
    this.GetMills();
  }

  SortOder(sortBy){
    if (this.param.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.param.SortOrder = "DESC"
    } else{
      this.param.SortOrder = "ASC"
    }
    this.param.SortColumnName = sortBy;
    this.GetMills();
  }

  Cancel(){    
    this.MillId = 0;
    this.frmMill.setValue({Millnumber:"",Millname:""});
    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide =false;
    this.CancelShowHide = false;
  }

  GetMills() {
    debugger;
    this._ShipmentExceptionService.getMillsList(this.param).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;      
      this.config.totalItems = JSON.parse(data).page.TotalCount;      
   });
  }

  pageChanged(event){
    this.config.currentPage = event;
    this.param.PageSelected = event;
    this.GetMills();
  }

  EditMill(item){
    this.MillId = item.MillId;
    this.frmMill.setValue({
      Millnumber:item.Millnumber,
      Millname:item.Millname
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide =true;
    this.CancelShowHide = true;
  }

  DeleteMill(millid){
    var meet = confirm("Are you sure. You want to delete the record?");
    if(meet) {
    this._ShipmentExceptionService.DeleteMill(millid).subscribe((data: any) => {   
         if(data == "MailingExists") {
          this.alertService.showError("Cannot delete record. Records from Mailinglist corresponding to the Mill should be deleted."); 
          return ;
         }
         if(data === "1") {
         this.GetMills();
         this.alertService.showSuccess("Record deleted successfully");
         } else {
          this.alertService.showError("Error while deleteing successfully");
         }
    });    
  }
}

AddMill(){
  this.MillId = 0;   
  this.AddShowHide = false;
  this.EditShowHide = false;
  this.CreateShowHide = true;
  this.UpdateShowHide =false;
  this.CancelShowHide = true;
}

Validation(frmM:FormGroup){
  let invalidfield : String = '';
      
if (frmM.invalid) {
    Object.keys(frmM.controls).forEach((key) => {
        if(frmM.get(key).invalid == true){
            if(invalidfield == ''){
                invalidfield = "Please enter " +  key.charAt(0).toUpperCase() + key.substr(1).toLowerCase()+ "<br/>";   
            } else {
                invalidfield += "Please enter " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/> ";
            }                 
        }
    });
    this.alertService.showError(invalidfield);
  }
}

  CreateMill() {  
  if (this.frmMill.invalid) {
    debugger;
    this.Validation(this.frmMill);
    return;
  }
  let MillsModel = {
    Millnumber: this.frmMill.get('Millnumber').value,
    Millname: this.frmMill.get('Millname').value,
    Createdby: "jagdish"
  }  

  let retvalue = this._ShipmentExceptionService.InsertUpdateMill(MillsModel);
  retvalue.pipe(
    catchError(err => {
      this.alertService.showError("Error while creating record!!!");
      return of(null);
    })).subscribe((value: any) => {      
    this.GetMills();          
    this.renderer.setAttribute(this.elMill.nativeElement, 'class','collapse');
    this.Cancel();      
    this.alertService.showSuccess("Record created successfully");      
    })      
  }

  UpdateMill() {
    if (this.frmMill.invalid) { 
      this.Validation(this.frmMill);
      return;
    }

    let MillsModel = {
      MillId: this.MillId,
      Millnumber: this.frmMill.get('Millnumber').value,
      Millname: this.frmMill.get('Millname').value,
      Modifiedby: "jagdish"
    }

    let retvalue = this._ShipmentExceptionService.InsertUpdateMill(MillsModel);

    retvalue.pipe(
      catchError(err => {
        alert("Error while creating record!!!");
        return of(null);
      })).subscribe((value: any) => {        
        this.GetMills();      
        this.renderer.setAttribute(this.elMill.nativeElement, 'class','collapse');
        this.Cancel();
        setTimeout("",1000);
        this.alertService.showSuccess("Record updated successfully");      
      })      
  }
}