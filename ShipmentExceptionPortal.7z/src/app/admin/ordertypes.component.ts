import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { ShipmentExceptionService } from '../../services/ShipmentException.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'ordertypes',
  templateUrl: './ordertypes.component.html'
})
export class OrderTypesComponent implements OnInit {
  items: any;
  @ViewChild('addOrderType') el:ElementRef;
  private route: ActivatedRoute;
  OrderTypeId:number;
  AddShowHide:boolean = true;
  EditShowHide:boolean = true;
  CreateShowHide:boolean = false;
  UpdateShowHide:boolean = false;  
  CancelShowHide = false;
  reverse: boolean = false;
  frmOrderType = new FormGroup({
    OrderType: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'ordertype',
    itemsPerPage: 2,
    currentPage: 0,
    totalItems: 0,
  };

  orderTypeParam = {
    SortColumnName :"Ordertype",
    SortOrder :"ASC",
    PageSelected:0,
    PageSize:2
  };

  constructor(private renderer: Renderer2, private _ShipmentExceptionService: ShipmentExceptionService, private alertService : AlertService, private storage: StorageService) { }

  ngOnInit() {  
    this.GetOrderType();
  }

  SortOder(sortBy){
    if (this.orderTypeParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.orderTypeParam.SortOrder = "DESC"
    } else{
      this.orderTypeParam.SortOrder = "ASC"
    }
    this.orderTypeParam.SortColumnName = sortBy;
    this.GetOrderType();
  }

  Cancel(){    
    this.OrderTypeId = 0;
    this.frmOrderType.setValue({OrderType:""});
    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide =false;
    this.CancelShowHide = false;
  }

  GetOrderType() {
    this._ShipmentExceptionService.GetOrderTypesDetail(this.orderTypeParam).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;      
      this.config.totalItems = JSON.parse(data).page.TotalCount;      
   });
  }

  pageChanged(event){
    this.config.currentPage = event;
    this.orderTypeParam.PageSelected = event;
    this.GetOrderType();
  }

  EditOrderType(item){
    this.OrderTypeId = item.OrdertypeId;
    this.frmOrderType.setValue({
      OrderType:item.Ordertype
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide =true;
    this.CancelShowHide = true;
  }

  DeleteOrderType(OrdertypeId){
    var meet = confirm("Are you sure. You want to delete the record?");
    if(meet) {
    this._ShipmentExceptionService.DeleteMill(OrdertypeId).subscribe((data: any) => {   
         if(data == "MailingExists") {
          this.alertService.showError("Cannot delete record. Records from Mailinglist corresponding to the OrderTpye should be deleted."); 
          return ;
         }
         if(data == "1") {
         this.GetOrderType();
         this.alertService.showSuccess("Record deleted successfully");
         } else {
          this.alertService.showError("Error while deleteing successfully");
         }
    });    
  }
}

AddOrderType(){
  this.OrderTypeId = 0;   
  this.AddShowHide = false;
  this.EditShowHide = false;
  this.CreateShowHide = true;
  this.UpdateShowHide =false;
  this.CancelShowHide = true;
}

Validation(frmM:FormGroup){
  let invalidfield : String = '';
      
if (frmM.invalid) {
    Object.keys(frmM.controls).forEach((key) => {
        if(frmM.get(key).invalid == true){
            if(invalidfield == ''){
                invalidfield = "Please enter " +  key.charAt(0).toUpperCase() + key.substr(1).toLowerCase()+ "<br/>";   
            } else {
                invalidfield += "Please enter " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/> ";
            }                 
        }
    });
    this.alertService.showError(invalidfield);
  }
}

CreateOrdertype() {  
  if (this.frmOrderType.invalid) {
    this.Validation(this.frmOrderType);
    return;
  }
  let OrderTypeModel = {
    Ordertype: this.frmOrderType.get('OrderType').value,
    Createdby: "jagdish"
  }  

  let retvalue = this._ShipmentExceptionService.InsertUpdateOrderType(OrderTypeModel);
  retvalue.pipe(
    catchError(err => {
      this.alertService.showError("Error while creating record!!!");
      return of(null);
    })).subscribe((value: any) => {      
    this.GetOrderType();          
    this.renderer.setAttribute(this.el.nativeElement, 'class','collapse');
    this.Cancel();      
    this.alertService.showSuccess("Record created successfully");      
    })      
  }

  UpdateOrdertype() {
    if (this.frmOrderType.invalid) { 
      this.Validation(this.frmOrderType);
      return;
    }

    let OrderTypeModel = {
      OrdertypeId: this.OrderTypeId,
      Ordertype: this.frmOrderType.get('OrderType').value,
      Modifiedby: "jagdish"
    }

    let retvalue = this._ShipmentExceptionService.InsertUpdateOrderType(OrderTypeModel);

    retvalue.pipe(
      catchError(err => {
        alert("Error while creating record!!!");
        return of(null);
      })).subscribe((value: any) => {        
        this.GetOrderType();      
        this.renderer.setAttribute(this.el.nativeElement, 'class','collapse');
        this.Cancel();
        setTimeout("",1000);
        this.alertService.showSuccess("Record updated successfully");      
      })      
  }
}