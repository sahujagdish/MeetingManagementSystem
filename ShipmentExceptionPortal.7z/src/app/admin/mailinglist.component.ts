import { OnInit, Component, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ShipmentExceptionService } from '../../services/ShipmentException.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'mailinglist',
  templateUrl: './mailinglist.component.html'
})

export class MailingListComponent implements OnInit {
  items: any;
  OrderTypeList: any[];
  MillList: any[];
  mill: any;
  @ViewChild('addEmailConfig') el: ElementRef;
  private route: ActivatedRoute;
  MaillingListId: number;
  AddShowHide: boolean = true;
  EditShowHide: boolean = true;
  CreateShowHide: boolean = false;
  UpdateShowHide: boolean = false;
  CancelShowHide = false;
  reverse: boolean = false;
  frmEmailConfig = new FormGroup({
    MillId: new FormControl('', [Validators.required]),
    Ordertype: new FormControl('', [Validators.required]),
    Planningteamdl: new FormControl('', [Validators.required, Validators.email]),
    Executionteamdl: new FormControl('', [Validators.required, Validators.email])
  });

  config = {
    id: 'emailconfig',
    itemsPerPage: 2,
    currentPage: 0,
    totalItems: 0,
  };

  mailingParam = {
    SortColumnName: 'Millname',
    SortOrder: 'ASC',
    PageSelected: 0,
    PageSize: 2
  };

  constructor(private renderer: Renderer2, private _ShipmentExceptionService: ShipmentExceptionService,
    private alertService: AlertService, private storage: StorageService) { }

  ngOnInit() {
    this.GetEmailConfig();
    this.GetOrderTypes();
    this.GetMills();
  }

  SortOder(sortBy) {
    if (this.mailingParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.mailingParam.SortOrder = "DESC"
    } else {
      this.mailingParam.SortOrder = "ASC"
    }
    this.mailingParam.SortColumnName = sortBy;
    this.GetEmailConfig();
  }

  onMillChange(event) {
    //console.log(this.frmEmailConfig.get("MillId").value);
  }

  Cancel() {
    this.MaillingListId = 0;
    this.frmEmailConfig.setValue({
      MillId: "",
      Ordertype: "",
      Planningteamdl: "",
      Executionteamdl: ""
    });

    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide = false;
    this.CancelShowHide = false;
  }

  GetEmailConfig() {
    this._ShipmentExceptionService.getMailingList(this.mailingParam).subscribe((data: any) => {
      this.items = data.PagedDataModel;
      this.config.totalItems = data.page.TotalCount;
    });
  }

  GetMills() {
    this._ShipmentExceptionService.getMills().subscribe((data: any) => {

      this.MillList = JSON.parse(data);
    });
  }

  GetOrderTypes() {
    this._ShipmentExceptionService.GetOrderTypes().subscribe((data: any) => {
      this.OrderTypeList = JSON.parse(data);
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.mailingParam.PageSelected = event;
    this.GetEmailConfig();
  }

  EditEmailConfig(item) {
    this.MaillingListId = item.Id;

    this.frmEmailConfig.setValue({
      MillId: item.MillId,
      Ordertype: item.OrdertypeId,
      Planningteamdl: item.Planningteamdl,
      Executionteamdl: item.Executionteamdl
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide = true;
    this.CancelShowHide = true;
  }

  DeleteEmailConfig(Id) {
    var meet = confirm("Are you sure. You want to delete the record?");
    if (meet) {
      this._ShipmentExceptionService.DeleteMailingList(Id).subscribe((data: any) => {
        if (data == "1") {
          this.GetEmailConfig();
          this.alertService.showSuccess("Record deleted successfully");
        } else {
          this.alertService.showError("Error while deleteing successfully");
        }
      });
    }
  }

  AddEmailConfig() {
    this.MaillingListId = 0;
    this.AddShowHide = false;
    this.EditShowHide = false;
    this.CreateShowHide = true;
    this.UpdateShowHide = false;
    this.CancelShowHide = true;
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';
    if (frmM.invalid) {
      Object.keys(frmM.controls).forEach((key) => {
        if (frmM.get(key).invalid == true) {

          if (frmM.get(key).errors.email) {
            if (invalidfield == '') {
              invalidfield = "Please enter correct emailid in " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
            } else {
              invalidfield += "Please enter correct emailid in " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
            }
          }

          if (frmM.get(key).errors.required) {
            if (invalidfield == '') {
              if (key == "MillId" || key == "Ordertype") {
                invalidfield = "Please select " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
              }
              if (key == "Planningteamdl" || key == "Executionteamdl") {
                invalidfield = "Please enter " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
              }
            } else {
              if (key == "MillId" || key == "Ordertype") {
                invalidfield += "Please select " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
              }
              if (key == "Planningteamdl" || key == "Executionteamdl") {
                invalidfield += "Please enter " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/>";
              }
            }
          }
        }
      });
      this.alertService.showError(invalidfield);
    }
  }

  CreateEmailConfig() {
    if (this.frmEmailConfig.invalid) {
      this.Validation(this.frmEmailConfig);
      return;
    }
    let Emailconfig = {
      Id: 0,
      MillId: parseInt(this.frmEmailConfig.get('MillId').value),
      OrdertypeId: parseInt(this.frmEmailConfig.get('Ordertype').value),
      Planningteamdl: this.frmEmailConfig.get('Planningteamdl').value,
      Executionteamdl: this.frmEmailConfig.get('Executionteamdl').value,
      Createdby: "jagdish"
    }

    debugger;

    let retvalue = this._ShipmentExceptionService.InsertUpdateMailingList(Emailconfig);
    retvalue.pipe(
      catchError(err => {
        this.alertService.showError("Error while creating record !!");
        return of(null);
      })).subscribe((value: any) => {

        if (value === "CombinationAllreadyExists") {
          this.alertService.showError("email configuration already exists !!");
          return;
        }
        if (value === "1") {
          this.GetEmailConfig();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
          this.alertService.showSuccess("Record created successfully");
        }
      })
  }

  UpdateEmailConfig() {
    if (this.frmEmailConfig.invalid) {
      this.Validation(this.frmEmailConfig);
      return;
    }
    let Emailconfig = {
      Id: this.MaillingListId,
      MillId: parseInt(this.frmEmailConfig.get('MillId').value),
      OrdertypeId: parseInt(this.frmEmailConfig.get('Ordertype').value),
      Planningteamdl: this.frmEmailConfig.get('Planningteamdl').value,
      Executionteamdl: this.frmEmailConfig.get('Executionteamdl').value,
      Modifiedby: 'jagdish'
    }

    let retvalue = this._ShipmentExceptionService.InsertUpdateMailingList(Emailconfig);

    retvalue.pipe(
      catchError(err => {
        alert("Error while updating record !!");
        return of(null);
      })).subscribe((value: any) => {
        if (value === "CombinationAllreadyExists") {
          this.alertService.showError("email configuration already exists !!");
          return;
        }

        if (value === "1") {
          this.GetEmailConfig();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
          setTimeout("", 1000);
          this.alertService.showSuccess("Record updated successfully");
        }
      })
  }
}
