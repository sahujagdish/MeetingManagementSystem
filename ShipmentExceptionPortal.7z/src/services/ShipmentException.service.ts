import { Injectable, Inject } from '@angular/core';
import { DataService } from './data.service';
import { dev,ConfigService } from '../services/config.service'; 

@Injectable()
export class ShipmentExceptionService {
  base: any
  constructor(private dataService: DataService, private configservice:ConfigService, @Inject(dev) env:any) {
    this.base = env;
  }

  public getMillsList(param:any) {  
    return this.dataService.post(this.base.version + "/GetMillsDetail", param);
  }

  public getMills() {  
    return this.dataService.get(this.base.version + "/Mills");
  }

  public getMill(id: number) {
    return this.dataService.get(this.base.version + "/Mill/" + id);
  }

  public InsertUpdateMill(MillsModel) {   
    return this.dataService.post(this.base.version + "/InsertUpdateMill", MillsModel);
  }

 public DeleteMill(id: number){
    return this.dataService.post(this.base.version + "/DeleteMill/" + id,"");
  }

  public GetOrderTypesDetail(param:any) {  
    return this.dataService.post(this.base.version + "/OrderTypesDetail", param);
  }

  public GetOrderTypes() {  
    return this.dataService.get(this.base.version + "/OrderTypes");
  }

  public GetOrderType(id: number) {
    return this.dataService.get(this.base.version + "/OrderType/" + id);
  }

  public InsertUpdateOrderType(OrderTypeModel) {   
    return this.dataService.post(this.base.version + "/InsertUpdateOrderType", OrderTypeModel);
  }

 public DeleteOrderType(id: number){
    return this.dataService.post(this.base.version + "/DeleteOrderType/" + id,"");
 }

 public getMailingList(param:any) {  
  return this.dataService.post(this.base.version + "/MailingList", param);
}

public getMailing(id: number) {
  return this.dataService.get(this.base.version + "/MailingList/" + id);
}

public InsertUpdateMailingList(MillsModel) {   
  return this.dataService.post(this.base.version + "/InsertUpdateMailingList", MillsModel);
}

public DeleteMailingList(id: number){
  return this.dataService.post(this.base.version + "/DeleteMailingList/" + id,"");
}

}


