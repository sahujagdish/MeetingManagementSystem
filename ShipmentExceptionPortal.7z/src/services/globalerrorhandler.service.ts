import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GlobalErrorHandlerService implements ErrorHandler {
  constructor(private injector: Injector, private router: Router) {
  }

  handleError(error: any) {
    const router = this.injector.get(Router);
    console.log(router.url);
    if (error instanceof HttpErrorResponse) {
      console.error("HTTP Status code: " + error.status);
      console.error("HTTP Response body: " + error.message);
     // alert("HTTP Status code: " + error.status + "\n\nError occured: " + error.error);      
    } else {
      console.error("Error occured: " + error.message);
      //alert("Error occured: " + error.message);
    }
    
    this.router.navigate(['/error']);
}
}