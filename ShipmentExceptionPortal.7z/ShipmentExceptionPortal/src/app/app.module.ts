import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule,ErrorHandler } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app.routes';
import { AppComponent } from './app.component';  
import { HeaderComponent } from './menu/header.component';
import { FooterBarComponent} from './menu/footer.component';
import { HttpClientModule } from '@angular/common/http';
import { AngularWebStorageModule } from 'angular-web-storage'; 
import { ToastrModule } from 'ngx-toastr';
import { AuthGuard } from '../security/auth.guard';
import { AuthService } from '../security/auth.service';
import { AlertService } from '../services/alert.service';
import { dev,ConfigService,ConfigFactory } from '../services/config.service';
import { GlobalErrorHandlerService } from '../services/globalerrorhandler.service';
import { SharedService } from '../services/shared.service';
import { ErrorComponent } from './error/error.component';
import { CPBShipmentExceptionsComponent } from './viewDetails/cpbshipmentexceptions.component'; 
import {DataService} from '../services/data.service';
import {UserService} from '../services/user.service';
import { MeetingResolver } from '../services/Meetingresolver';
import { ShipmentExceptionService } from '../services/ShipmentException.service';
import { AuthInterceptor } from '../services/authInceptor.service';
import { SplitAttendeesPipe } from '../services/CustomPipes';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HTTP_INTERCEPTORS} from '@angular/common/http';
import { LandingComponent } from './viewDetails/LandingPage.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterBarComponent,
    ErrorComponent, 
    SplitAttendeesPipe,
    LandingComponent,
    CPBShipmentExceptionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, 
    ReactiveFormsModule,
    AngularWebStorageModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()    ,
    NgMultiSelectDropDownModule.forRoot()
  ],
  exports: [   
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ AuthService, AuthGuard, DataService, UserService,ErrorHandler, AlertService,SharedService,ShipmentExceptionService,MeetingResolver,
              ConfigService,
              { provide:ErrorHandler, useClass:GlobalErrorHandlerService}, 
              { provide:'config.json', useValue:'./assets/config.json'}, 
              { provide:'BASE-API-VARIABLE',useValue:'dev'},
              {
                provide:dev, useFactory:ConfigFactory,
                deps:[ConfigService,'config.json','BASE-API-VARIABLE']
              }
              , {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
