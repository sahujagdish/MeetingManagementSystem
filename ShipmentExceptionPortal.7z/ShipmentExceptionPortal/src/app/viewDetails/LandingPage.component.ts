import { OnInit,Component } from '@angular/core';
import { Router, ActivatedRoute, Data } from '@angular/router';
import { DataService } from '../../services/data.service';
import { SharedService } from '../../services/shared.service';

import { ShipmentExceptionService } from '../../services/ShipmentException.service';

import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';

@Component({
    selector: 'Landing',
    templateUrl: './LandingPage.component.html'
})

export class LandingComponent implements OnInit {
    constructor(private alertService : AlertService, private storage: StorageService, private _sharedService: SharedService, private router: Router, private activerouter: ActivatedRoute, private dataService: DataService, private shipmentExceptionService: ShipmentExceptionService) {

    }


    ngOnInit(){

    }
}

