import { OnInit, OnChanges, Component, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { SharedService } from '../../services/shared.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';

@Component({
    selector: 'insertupdateshipmentexceptions',
    templateUrl: './insertupdateshipmentexceptions.component.html'
})

export class insertupdateshipmentexceptionsComponent implements OnInit {

    constructor(private alertService : AlertService, private formBuilder: FormBuilder, private storage: StorageService, private _sharedService: SharedService, private router: Router, private activerouter: ActivatedRoute) {

    }

    ngOnInit(){
        
    }
}