import { NgModule } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { APP_BASE_HREF } from '@angular/common'; 
import { LandingComponent } from './viewDetails/LandingPage.component'; 
import { AuthGuard } from '../security/auth.guard';
import { MeetingResolver } from '../services/Meetingresolver';
import { CPBShipmentExceptionsComponent } from './viewDetails/cpbshipmentexceptions.component';
import { ErrorComponent } from './error/error.component';

const appRoutes: Routes = [
    { path: '', component: LandingComponent },
    { path: 'Home', redirectTo: ''},
    { path: 'cpbshipmentexceptions', component: CPBShipmentExceptionsComponent},
    { path: 'administration', loadChildren: () => import('./admin/admin.module').then(m => m.adminModule)},    
    { path: '**', redirectTo: '' },
    { path: 'error', component: ErrorComponent},    
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)], 
    exports: [RouterModule]
})

export class AppRoutingModule {
     
}