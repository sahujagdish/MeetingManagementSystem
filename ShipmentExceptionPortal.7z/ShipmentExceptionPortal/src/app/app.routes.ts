import { NgModule } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { APP_BASE_HREF } from '@angular/common'; 
import { LandingComponent } from './viewDetails/LandingPage.component'; 
import { AuthGuard } from '../security/auth.guard';
import { MeetingResolver } from '../services/Meetingresolver';
import { cpbshipmentexceptionsComponent } from './viewDetails/cpbshipmentexceptions.component';
import { ErrorComponent } from './error/error.component';
import { insertupdateshipmentexceptionsComponent } from './viewDetails/insertupdateshipmentexceptions.component'; 

const appRoutes: Routes = [
    { path: 'error', component: ErrorComponent},
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: LandingComponent},
    { path: 'cpbshipmentexceptions', component: cpbshipmentexceptionsComponent},
    { path: 'insertupdatecpbshipmentexceptions', component: insertupdateshipmentexceptionsComponent},
    { path: 'administration', loadChildren: () => import('./admin/admin.module').then(m => m.adminModule)},        
    { path: '**', redirectTo: '' },
        
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)], 
    exports: [RouterModule]
})

export class AppRoutingModule {
     
}