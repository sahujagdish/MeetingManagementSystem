import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mills',
  templateUrl: './mills.component.html'
})
export class MillsComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}