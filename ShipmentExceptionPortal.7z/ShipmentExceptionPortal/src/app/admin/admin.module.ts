import { NgModule } from '@angular/core'; 
import { AdminRoutingModule } from './admin.route'; 
import { RolesComponent } from './roles.component'; 
import { MillsComponent } from './mills.component'; 
import { RoleConfigComponent } from './roleconfig.component';

@NgModule({
  imports: [    
    AdminRoutingModule 
  ],
  declarations:[
    RolesComponent,
    MillsComponent,
    RoleConfigComponent
  ]
})
export class adminModule { 
  
}
