import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'roleconfig',
  templateUrl: './roleconfig.component.html'
})
export class RoleConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}