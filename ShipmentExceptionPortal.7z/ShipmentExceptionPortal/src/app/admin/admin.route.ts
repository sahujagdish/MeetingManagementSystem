import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MillsComponent } from './mills.component';
import { RolesComponent } from './roles.component';
import { RoleConfigComponent } from './roleconfig.component';

const adminRoutes: Routes = [
    {
        path:'', children:[           
            {path:'mills', component: MillsComponent},
            {path: 'roles', component: RolesComponent},
            {path: 'roleconfig', component: RoleConfigComponent}
        ]
    } 
];

@NgModule({
    imports: [RouterModule.forChild(adminRoutes)],
    exports: [RouterModule]
})
export class AdminRoutingModule {
     
 }