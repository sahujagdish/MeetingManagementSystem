import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MillsComponent } from './mills.component';
import { OrderTypesComponent } from './ordertypes.component';
import { MailingListComponent } from './mailinglist.component';
import { AdministrationComponent } from './administration.component';
import { ErrorComponent } from '../../app/error/error.component';
const adminRoutes: Routes = [
    {
        path:'', children:[             
            {path:'', component: AdministrationComponent},
            {path:'mills', component: MillsComponent},
            {path: 'ordertypes', component: OrderTypesComponent},
            {path: 'mailinglist', component: MailingListComponent},
            { path: 'error', component: ErrorComponent},
        ]
    } 
];

@NgModule({
    imports: [RouterModule.forChild(adminRoutes)],
    exports: [RouterModule]
})
export class AdminRoutingModule {
     
 }