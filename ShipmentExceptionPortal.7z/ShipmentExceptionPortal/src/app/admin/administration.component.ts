import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'administration',
  templateUrl: './administration.component.html'
})
export class AdministrationComponent implements OnInit {

  items:any[];
  constructor() { }

  ngOnInit() {
  } 

}