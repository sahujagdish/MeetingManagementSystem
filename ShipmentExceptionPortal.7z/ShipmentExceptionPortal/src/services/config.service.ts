import { Injectable, InjectionToken } from "@angular/core";

export function ConfigFactory(configService: ConfigService, file: string, property: any) {
return configService.loadJSON(file)[property];
}

export const dev = new InjectionToken<any>('dev');

@Injectable()
export class ConfigService {

    public config: any;
    constructor() {
    }

    loadJSON(filePath) {
        const json = this.loadTextFileAjaxSync(filePath, "application/text");
        return JSON.parse(json);
    }

    loadTextFileAjaxSync(filePath, mimeType) {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", filePath, false);
        if (mimeType != null) {
            if (xmlhttp.overrideMimeType) {
                xmlhttp.overrideMimeType(mimeType);
            }
        }
        xmlhttp.send();
        if (xmlhttp.status == 200) {
            return xmlhttp.responseText;
        } else {
            return null;
        }
    }
}