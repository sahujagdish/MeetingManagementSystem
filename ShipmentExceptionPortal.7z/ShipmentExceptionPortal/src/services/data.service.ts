import { Injectable, Inject} from "@angular/core";
import { Observable, of } from 'rxjs';
import { map, retry, catchError } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { dev,ConfigService } from '../services/config.service'; 
import { StorageService } from '../services/storage.service';
import { Router } from '@angular/router';

@Injectable()
export class DataService {
  
    respo: any;
    serviceData: any; 
    baseUrl: string; 
    options : any  = {
        headers: new HttpHeaders().set('Content-Type', 'application/json')
        .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
        .set('Access-Control-Allow-Origin', '*')
        .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS,PUT,DELETE'),
      };

    constructor(private httpClient: HttpClient,private configservice:ConfigService, @Inject(dev) baseurl:any, storage: StorageService, private router: Router) {//, private userDetails: UserDetails) {
        this.baseUrl = baseurl.API_URL;         
    }

    get(endpoint): Observable<any>{
        return this.httpClient.get(this.baseUrl + endpoint, this.options).pipe(            
            map(response  => {
                     let body = JSON.parse(JSON.stringify(response));
                     return body || {};
                }),
            catchError(
                err => {
                    debugger;
                  console.log(err);
                 return of(null);
                }
            ));
    }

    post(endpoint,body):Observable<any>{
        return this.httpClient.post(this.baseUrl + endpoint,body,this.options)
        .pipe(
            map( response  => {                
                     let body = JSON.parse(JSON.stringify(response));
                     return body || {};
                }
            ),
             catchError( err => {
                alert(err);
                this.router.navigate(['/error']);
                return of(null);
            }))
    };

     async postpromise(endpoint,body){
        let resp:any;
        
        let promise = await new Promise((resolve, reject) => {       
            this.httpClient.post(this.baseUrl + endpoint,body,)
            .toPromise()
            .then(res => { // Success
                resp = res
                console.log(res);
                resolve();
              });
        });        
        return resp;
    }
}
