import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from "rxjs";
import { StorageService } from './storage.service';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({

  providedIn: 'root'

})
export class AuthInterceptor implements HttpInterceptor {
  constructor(private storage: StorageService, private activeRoute: ActivatedRoute) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.activeRoute['_routerState'].snapshot.url != '/login') {
      var bareartoken = this.storage.$SessionStorageGet('globalAuth');
      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${bareartoken.Token}`,
          'Content-Type': 'application/json'
        }
      });
    }
    return next.handle(req);
  }

}