import { Pipe, PipeTransform } from '@angular/core';
import { stringify } from 'querystring';

@Pipe({ name: 'splitattendees' })
export class SplitAttendeesPipe implements PipeTransform {
  transform(value:any, [separator]):string { 
    let attendess : [];
    let formatstr : string;
    if(value.length >= 1) {    

        formatstr = "<ul class='padd-15'>";
        for (var i = 0; i < value.length;  i++) {
            if(formatstr == undefined ) {
                formatstr = `<li>${value[i].name}</li>`;
            } else {
                formatstr += `<li>${value[i].name}</li>`;
            }        
        }

        formatstr += '</ul>';
    } else {
        formatstr = '';
    }
    return formatstr;    
  }
}