import { Injectable, Inject} from "@angular/core";
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { dev,ConfigService } from '../services/config.service'; 
import { StorageService } from '../services/storage.service';
@Injectable()
export class DataService {
  
    respo: any;
    serviceData: any; 
    baseUrl: string; 
    header = new HttpHeaders({
        'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS,PUT,DELETE',
        'Content-Type': 'application/json'
        
    });

    constructor(private httpClient: HttpClient,private configservice:ConfigService, @Inject(dev) baseurl:any, storage: StorageService) {//, private userDetails: UserDetails) {
        this.baseUrl = baseurl.API_URL;  
    }

    get(endpoint): Observable<any>{
        return this.httpClient.get(this.baseUrl + endpoint);
    }

    // private headers = new HttpHeaders(
    //     {'Content-Type': 'application/json'}
    //   );

    async post(endpoint,body){
        let resp:any;
        //let promise;
        //promise = await this.httpClient.post(this.baseUrl + endpoint,body,{ headers:this.header}).toPromise();
       
        
        let promise = await new Promise((resolve, reject) => {
       debugger;
           // const options = { headers: this.headers};
            this.httpClient.post(this.baseUrl + endpoint,body)
            .toPromise()
            .then(res => { // Success
                resp = res
                console.log(res);
                resolve();
              });
        });
         //.pipe(map((res: Response) => resp = res.json()));
         return resp;
    }
}
