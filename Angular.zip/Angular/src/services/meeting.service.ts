import { Injectable, Inject } from '@angular/core';
import { DataService } from '../services/data.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';
@Injectable()
export class MeetingService {

  baseurl: any
  constructor(private dataService: DataService) {

  }

  private meetings = [
    {
      id: 1,
      subject: 'shipment',
      attendees: [{ id: '1', name: 'Jagdish' }, { id: '3', name: 'Krishna' }],
      agenda: 'product shipment',
      datetime: "2020-03-12T00:00"
    },
    {
      id: 2,
      subject: 'Productionserver',
      attendees: [{ id: '1', name: 'Jagdish' }, { id: '2', name: 'Sravan' }],
      agenda: 'Discussion on Project Meeting yuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu677777777 yuuuuuuuuuut666666666666&&&&**',
      datetime: "2020-03-15T00:00"
    },
  ];

  private attendeesList: any = [{ id: '1', name: 'Jagdish' }, { id: '2', name: 'Sravan' }, { id: '3', name: 'krishna' }];

  public getAttendeesList() {
    // return this.attendeesList;
    return this.dataService.get("api/protected/getEmployee");
  }

  public getCalendar() {
    //return this.meetings;

    return this.dataService.get("api/protected/getCalendar");
  }

  public getMeeting(id: number) {
    return this.dataService.get("api/protected/getMeeting/" + id);
  }

  UpdateMeeting(id: number, serverInfo: { subject: any, attendees: [], agenda: string, datetime: string, UpdatedBy:string }) {
  debugger;
    let meeting = {
      id: id, subject: serverInfo.subject, attendees: serverInfo.attendees,
      agenda: serverInfo.agenda, datetime: serverInfo.datetime, UpdatedBy:serverInfo.UpdatedBy
    };
    return this.dataService.post("api/protected/UpdateMeeting", meeting);
  }

  CreateMeeting(id: number, serverInfo: { subject: any, attendees: [], agenda: string, datetime: string, CreatedBy:string }) {
    let meeting = {
      id: id, subject: serverInfo.subject, attendees: serverInfo.attendees,
      agenda: serverInfo.agenda, datetime: serverInfo.datetime, CreatedBy:serverInfo.CreatedBy
    };
    return this.dataService.post("api/protected/CreateMeeting", meeting);
  }

  MeetingDelete(id: number, UpdatedBy:string){
    let meeting = {
      id: id, UpdatedBy:UpdatedBy
    };
    return this.dataService.post("api/protected/MeetingDelete", meeting);
  }
}


