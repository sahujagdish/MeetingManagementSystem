import { Injectable } from "@angular/core";
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AlertService {

    constructor(private toastr: ToastrService) {}

    public showSuccess(message: any) {
        this.toastr.success(message, 'Success',{timeOut: 2000});
      }

    public showError(message: any) {
      this.toastr.error(message, 'Error', {timeOut: 3000});
    }

    public showWarning(message: any) {
      this.toastr.warning(message, 'Warn', {timeOut: 3000});
    }
}