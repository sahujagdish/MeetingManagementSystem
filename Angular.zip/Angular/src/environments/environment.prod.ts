export const environment = {
  production: true,
  env:'production',
  WebApiUrl:  "http://localhost/api/"
};
