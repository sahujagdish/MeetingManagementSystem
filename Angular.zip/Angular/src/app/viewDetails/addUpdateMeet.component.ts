import { OnInit, OnChanges, Component, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Data } from '@angular/router';
import { DataService } from '../../services/data.service';
import { SharedService } from '../../services/shared.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { MeetingService } from '../../services/meeting.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { StorageService } from '../../services/storage.service';

@Component({
    selector: 'addUpdateMeet',
    templateUrl: './addUpdateMeet.component.html'
})

export class AddUpdateMeetComponent implements OnInit {

    constructor(private formBuilder: FormBuilder, private storage: StorageService, private _sharedService: SharedService, private router: Router, private activerouter: ActivatedRoute, private dataService: DataService, private meetingService: MeetingService) {

    }
    meeting: {
        id: number,
        subject: any;
        attendees: any[];
        agenda: string;
        datetime: string;
    };

    attendeeslist: any[];
    dropdownList = [];
    selectedItems = [];
    dropdownSettings: IDropdownSettings = {};
    createShowHide: string;
    updateShowHide: string;
    MeetingId: any;

    myCalendar = new FormGroup({
        'subject': new FormControl('', Validators.required),
        'attendees': new FormControl('', [Validators.required, Validators.minLength(1)]),
        'agenda': new FormControl('', [Validators.required]),
        'datetime': new FormControl('', [Validators.required])
    });
    ngOnInit() {

        this.MeetingId = this.activerouter.params['value'].id;

        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true

        };

        this.meeting = { id: 0, agenda: '', attendees: [], datetime: '', subject: '' };
        //this.attendeeslist = this.meetingService.getAttendeesList();


        this.meetingService.getAttendeesList().subscribe((data: any[]) => {
            this.attendeeslist = data;
        });

        if (this.activerouter.params['value'].id != 0) {

            this.meetingService.getMeeting(+this.activerouter.params['value'].id).subscribe((data: any) => {
                this.meeting = data;
            })
            this.createShowHide = "hidden";
            this.updateShowHide = "visible";
        } else {
            this.meeting = { id: 0, agenda: '', attendees: [], datetime: '', subject: '' };
            this.createShowHide = "visible";
            this.updateShowHide = "hidden";
        }

        //   this.activerouter.data.subscribe(            
        //     (data : Data) => {     
        //         debugger;           
        //         console.log(data);
        //         if(data.meeting != undefined) {
        //             this.meeting = data['meeting'];
        //             this.createShowHide = "hidden";
        //             this.updateShowHide = "visible";
        //         } else {
        //             this.meeting = {id:0, agenda:'',attendees:[], datetime:'',subject:''};
        //             this.createShowHide = "visible";
        //             this.updateShowHide = "hidden";
        //         }


        //         //this.meeting.datetime = new Date(this.meeting.datetime.)
        //     }
        // );
        //var grp = this.myCalendar;
        console.log(this.myCalendar);
        console.log(this.myCalendar.pristine);
    }



    showattendessList() {

    }

    onItemSelect() {

    }

    onSelectAll() {

    }

    UpdateMeeting() {

        console.log(this.myCalendar);
        console.log(this.myCalendar.pristine);
        if (this.myCalendar.invalid) {
            return;
        }

        var bareartoken = this.storage.$SessionStorageGet('globalAuth');

        let serverInfo = {
            subject: this.myCalendar.get('subject').value,
            attendees: this.myCalendar.get('attendees').value,
            agenda: this.myCalendar.get('agenda').value,
            datetime: this.myCalendar.get('datetime').value,
            UpdatedBy: bareartoken.Username
        }

        debugger;

        let retvalue = this.meetingService.UpdateMeeting(this.MeetingId, serverInfo);

        debugger;
        retvalue.then((value:any) => {
            alert("Record updated successfully");
        }).catch((value:any) => {
            alert("Error updating record !!!");
        });
       // this.router.navigate(['/']);
    }

    SubmitMeeting() {
        console.log(this.myCalendar);
        console.log(this.myCalendar.pristine);
        if (this.myCalendar.invalid) {
            return;
        }

        var bareartoken = this.storage.$SessionStorageGet('globalAuth');

        let serverInfo = {
            subject: this.myCalendar.get('subject').value,
            attendees: this.myCalendar.get('attendees').value,
            agenda: this.myCalendar.get('agenda').value,
            datetime: this.myCalendar.get('datetime').value,
            CreatedBy:bareartoken.Username
        }

        let a = this.meetingService.CreateMeeting(this.MeetingId, serverInfo);

        this.router.navigate(['/']);
    }
}