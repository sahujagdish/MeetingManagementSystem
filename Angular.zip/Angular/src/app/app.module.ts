import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule,ErrorHandler } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app.routes';
import { AppLoginComponent } from './login/applogin.component';
import { AppComponent } from './app.component';  
import { Routes, RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { HeaderComponent } from './menu/header.component';
import { FooterBarComponent} from './menu/footer.component';
import { config } from 'rxjs';
import { Http, Response, Headers, URLSearchParams, HttpModule } from "@angular/http";
import { HttpClientModule } from '@angular/common/http';
import { AngularWebStorageModule } from 'angular-web-storage'; 
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { ToastrModule } from 'ngx-toastr';
import { helpComponent } from './admin/help.component';
import { AuthGuard } from '../security/auth.guard';
import { AuthService } from '../security/auth.service';
import { AlertService } from '../services/alert.service';
import { dev,ConfigService,ConfigFactory } from '../services/config.service';
import { GlobalErrorHandlerService } from '../services/globalerrorhandler.service';
import { SharedService } from '../services/shared.service';
import { ErrorComponent } from './error/error.component';
import { ViewDetailComponent } from './viewDetails/viewDetails.component'; 
import { AddUpdateMeetComponent } from './viewDetails/addUpdateMeet.component'; 
import {DataService} from '../services/data.service';
import {UserService} from '../services/user.service';
import { HomeLayoutComponent } from '../layouts/home-layout.component';
import { LoginLayoutComponent } from '../layouts/login-layout.component';
import { accessrightsComponent } from './admin/accessrights.component';
import { userroleComponent } from './admin/userrole.component';
import { MeetingResolver } from '../services/Meetingresolver';
import { MeetingService } from '../services/meeting.service';
import { AuthInterceptor } from '../services/authInceptor.service';
import { SplitAttendeesPipe } from '../services/CustomPipes';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HTTP_INTERCEPTORS} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AppLoginComponent,
    HeaderComponent,
    FooterBarComponent,
    ViewDetailComponent,
    helpComponent,
    ErrorComponent, 
    HomeLayoutComponent,
    LoginLayoutComponent,
    userroleComponent,
    accessrightsComponent,
    AddUpdateMeetComponent,
    SplitAttendeesPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule, 
    ReactiveFormsModule,
    AngularWebStorageModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()    ,
    NgMultiSelectDropDownModule.forRoot()
  ],
  exports: [   
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ AuthService, AuthGuard, DataService, UserService,ErrorHandler, AlertService,SharedService,MeetingService,MeetingResolver,
              ConfigService,
              { provide:ErrorHandler, useClass:GlobalErrorHandlerService}, 
              { provide:'config.json', useValue:'./assets/config.json'}, 
              { provide:'BASE-API-VARIABLE',useValue:'dev'},
              {
                provide:dev, useFactory:ConfigFactory,
                deps:[ConfigService,'config.json','BASE-API-VARIABLE']
              }
              , {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
