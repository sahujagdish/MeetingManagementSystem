import { OnInit, OnChanges, Component, Input, Output} from '@angular/core';
import { Router, ActivatedRoute, UrlSegment  } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { AuthService } from '../../security/auth.service'; 
import { StorageService } from '../../services/storage.service'; 
//import { BehaviorSubject } from 'rxjs';

@Component({   
    selector: 'header',
    templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit, OnChanges{
    Username : any;        
    isLoggedIn$: Observable<boolean>;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, public storage: StorageService, private authService: AuthService) {        
       var token = this.storage.$SessionStorageGet('globalAuth');
       this.Username = token.Username;
    }

    onLogout() {
        this.authService.logout();
    }

    ngOnInit() {   
        this.isLoggedIn$ = this.authService.isLoggedIn;
    }   

    ngOnChanges() {   
         
    }
}