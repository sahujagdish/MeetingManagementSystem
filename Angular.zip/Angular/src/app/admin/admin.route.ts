import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { userroleComponent } from './userrole.component';
import { accessrightsComponent } from './accessrights.component';
import { AuthGuard } from '../../security/auth.guard';

const adminRoutes: Routes = [
    {
        path:'', children:[           
            {path: 'userrole', component: userroleComponent},
            {path: 'accessrights', component: accessrightsComponent},
        ]
    } 
];

@NgModule({
    imports: [RouterModule.forChild(adminRoutes)],
    exports: [RouterModule]
})
export class AdminRoutingModule {
     
 }