import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
@Component({   
    selector: 'helpcomp',
    templateUrl: './help.component.html'
})

export class helpComponent implements OnInit {   

    constructor(private router: Router) {
            
    }
 
    
    ngOnInit() { 
       
    };    
} 


