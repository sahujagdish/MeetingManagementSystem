import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-layout',
  template: `
  <nav class="navbar navbar-inverse border-top"><div class="container-fluid">     
  <div class="navbar-header"> 
  <a class="brand" style="display:flex;display:-ms-flexbox;-ms-flex-wrap:nowrap;align-items:center" href="javascript:void(0);">
      </a>
    </div>
    <a class="navbar-right"><span style="font: Verdana, Geneva, sans-serif; font-weight:bold; font-size:25px; Color:#bb0e08;">Meeting Management System&nbsp;&nbsp;</span></a>
    </div>
    </nav>
    <router-outlet></router-outlet>    
    <footerBar></footerBar>
  `,
  styles: []
})
export class LoginLayoutComponent {}
