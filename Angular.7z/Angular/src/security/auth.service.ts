import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { User, UserService } from '../services/user.service';
import { StorageService } from '../services/storage.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { dev, ConfigService } from '../services/config.service';

@Injectable()
export class AuthService {
  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  userservice: any;
  storageService: any;
  baseUrl: string;
  get isLoggedIn() {
    if (this.storageService.$SessionStorageGet('globalAuth') != null) {
      this.loggedIn.next(true);
      return this.loggedIn.asObservable();
    } else {
      this.loggedIn.next(false);
      return this.loggedIn.asObservable();
    }
  }

  constructor(private router: Router, private configservice: ConfigService, @Inject(dev) baseurl: any, private user: UserService, storage: StorageService, private httpClient: HttpClient) {
    this.baseUrl = baseurl.API_URL;
    this.userservice = user;
    this.storageService = storage;
  }

  async  login(user: User) {
    if (user.Username !== '' && user.Password !== '') {
      if (this.storageService.$SessionStorageGet('globalAuth') == null) {
        debugger;
        let url = this.userservice.authenticate();
        let authurl = this.baseUrl + url;
        await new Promise((resolve, reject) => {
          this.httpClient.post(authurl, user)
            .toPromise()
            .then(res => { // Success
              debugger;
              alert(JSON.stringify(res));
              this.storageService.$SessionStorageSet('globalAuth', res);
              this.loggedIn.next(true);
              this.router.navigate(['/']);
              console.log(res);
              resolve();
            });
        });
        
      }
    }
  }

  logout() {
    this.loggedIn.next(false);
    this.storageService.$SessionStorageRemove('globalAuth');
    this.router.navigate(['/login']);
  }
}