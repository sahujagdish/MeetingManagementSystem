import {Resolve, ActivatedRouteSnapshot,RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs/observable';
import { Injectable } from '@angular/core';
import {MeetingService} from './meeting.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';

interface Meeting{
    id:number;
    subject : any;
    attendees : any[];
    agenda:string;
    datetime:string;
}

@Injectable()
export class MeetingResolver implements Resolve<Meeting> {
  meeting:any;
  constructor(private meetingService: MeetingService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Meeting> | Promise<Meeting> | Meeting {
    debugger; 
    if(route.params['id'] != 0){  
     // this.meetingService.getMeeting(+route.params['id']).subscribe((data : any) => {            
      //this.meeting = data;
    
  //});
}
  setTimeout('',1000);
  return this.meeting;
  }
}
