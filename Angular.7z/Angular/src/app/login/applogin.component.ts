import { OnInit, Component,  Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { StorageService } from '../../services/storage.service';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../../security/auth.service';
import { AlertService } from '../../services/alert.service';
import { SharedService } from '../../services/shared.service'; 

@Component({
    selector: 'app-login',
    templateUrl: './applogin.component.html'
})

export class AppLoginComponent implements OnInit {
    private route: ActivatedRoute;
    myForm = new FormGroup({
        Username: new FormControl('admin'),
        Password: new FormControl('admin')
    });

    constructor(  private router: Router, private _sharedService: SharedService, 
        private authService: AuthService, private alertService: AlertService, private storage: StorageService) {
       
        
    }

    ngOnInit() {
       
    }

    loadMainScreenInfo() {
     this.storage.$SessionStorageSet('globalAuth',null);
     this.authService.login(this.myForm.value);
        
    }
}



