import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common'; 
import { AppLoginComponent } from './login/applogin.component'; 
import { ViewDetailComponent } from './viewDetails/viewDetails.component'; 
import { helpComponent } from './admin/help.component';
import { AuthGuard } from '../security/auth.guard';
import { HomeLayoutComponent } from '../layouts/home-layout.component';
import { LoginLayoutComponent } from '../layouts/login-layout.component';
import { AddUpdateMeetComponent } from './viewDetails/addUpdateMeet.component'; 
import { userroleComponent } from './admin/userrole.component';
import { accessrightsComponent } from './admin/accessrights.component';
import { MeetingResolver } from '../services/Meetingresolver';

const appRoutes: Routes = [
    {
        path: '',
        component: HomeLayoutComponent,        
        children: [
          {path: '', component: ViewDetailComponent,canActivate: [AuthGuard] },
          {path: 'AddUpdateMeet/:id', component: AddUpdateMeetComponent,canActivate: [AuthGuard] },
        ]
      },
      {
        path: '',
        component: LoginLayoutComponent,
        children: [
          {
            path: 'login',
            component: AppLoginComponent
          },
          {
            path: 'help',
            component: helpComponent
          }
        ]
      },
      { path: '**', redirectTo: '' }

//     {path: '', component: ViewDetailComponent, canActivate: [AuthGuard]},
//     {path: 'login', component: AppLoginComponent},
//     {path: 'help', component: helpComponent},
//    {path: 'viewdetail', component: ViewDetailComponent, canActivate: [AuthGuard]},  
   
//     {path: 'error', component: ErrorComponent},
//     {path: 'admin', loadChildren: './admin/admin.module#adminModule'},
//     { path: '**', redirectTo: ''}
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)], 
    exports: [RouterModule]
})

export class AppRoutingModule {
     
 }