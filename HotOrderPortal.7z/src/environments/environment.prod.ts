export const environment = {
  production: true,
  env:'prod', 
  "API_URL":"https://localhost:5002/api/v1"
};
