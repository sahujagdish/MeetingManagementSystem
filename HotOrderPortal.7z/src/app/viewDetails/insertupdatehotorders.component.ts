import { OnInit, OnChanges, Component, Input, Output, EventEmitter, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../../services/shared.service';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HotOrderService } from 'src/services/HotOrder.service';

@Component({
    selector: 'insertupdatehotorders',
    templateUrl: './insertupdatehotorders.component.html'
})

export class insertupdatehotordersComponent implements OnInit {

    public frmOrdersException: FormGroup;
    public transferSOLIList: FormArray;
    requirerolls: boolean;
    reqmodeshift: boolean;
     
    phonepattern = new RegExp("/^[(]\d{3}[)]\d{3}-\d{4}$");

    constructor(private renderer: Renderer2, private fb: FormBuilder, private _HotOrderService: HotOrderService, private alertService: AlertService, private storage: StorageService) {

    }

    ngOnInit() {
        debugger;
        this.frmOrdersException = this.fb.group({
            salesorder: new FormControl('', [Validators.required, Validators.minLength(1)]),
            lineitemnumber: new FormControl('', [Validators.required, Validators.minLength(1)]),
            desireddeliverydate: new FormControl('', [Validators.required, Validators.minLength(1)]),
            desireddeliverytime: new FormControl('', [Validators.required, Validators.minLength(1)]),
            hotweight: new FormControl('', [Validators.required, Validators.minLength(1)]),
            exceptionreason: new FormControl('', [Validators.required, Validators.minLength(1)]),
            customerserviceemail: new FormControl('', [Validators.required, Validators.minLength(1)]),
            afterhoursreceiver: new FormControl('', [Validators.required, Validators.minLength(1)]),
            afterhoursphone: new FormControl('', [Validators.required]), // Validators.pattern(this.phonepattern)
            requirerolls: new FormControl(''),
            transferSOLI: this.fb.array([this.AddionalTransferSOLI()]),
            reqmodeshift: new FormControl(''),
            modeshift: new FormControl(''),
            remainingbalanceshiftmode: new FormControl(''),
            requestcomments: new FormControl('')
        });

        debugger;

        this.transferSOLIList = this.frmOrdersException.get('transferSOLI') as FormArray;

    }

    AddionalTransferSOLI(): FormGroup {
        return this.fb.group({
            transfersalesorder: ['', Validators.compose([Validators.required])],
            transferlineitem: ['', Validators.compose([Validators.required, Validators.email])]
        });
    }

    AddSOLI() {
        this.transferSOLIList.push(this.AddionalTransferSOLI());
    }

    RemoveSOLI(index) {
        this.transferSOLIList.removeAt(index);
    }

    GetHotOrders() {
        debugger;
        // this._HotOrderService.getMillsList(this.param).subscribe((data: any) => {
        //     //this.items = JSON.parse(data).PagedDataModel;
        // });
    }


    DeleteMill(millid) {
        var meet = confirm("Are you sure. You want to delete the record?");
        if (meet) {
            this._HotOrderService.DeleteMill(millid).subscribe((data: any) => {
                if (data == "MailingExists") {
                    this.alertService.showError("Cannot delete record. Records from Mailinglist corresponding to the Mill should be deleted.");
                    return;
                }
                if (data === "1") {
                    this.GetHotOrders();
                    this.alertService.showSuccess("Record deleted successfully");
                } else {
                    this.alertService.showError("Error while deleteing successfully");
                }
            });
        }
    }

    Validation(frmM: FormGroup) {

        let invalidfield: String = '';

        if (frmM.invalid) {
            Object.keys(frmM.controls).forEach((key) => {
                if (frmM.get(key).invalid == true) {                    
                    if (key === "salesorder") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Sales Order #" + "<br/>";
                        } else {
                            invalidfield += "Please enter Sales Order #" + "<br/>";
                        }
                    }
                    if (key === "lineitemnumber") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Line Item #" + "<br/>";
                        } else {
                            invalidfield += "Please enter Line Item #" + "<br/>";
                        }
                    }
                    if (key === "desireddeliverydate") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Desired Delivery Date" + "<br/>";
                        } else {
                            invalidfield += "Please enter Desired Delivery Date" + "<br/>";
                        }
                    }
                    if (key === "desireddeliverytime") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Desired Delivery Time" + "<br/>";
                        } else {
                            invalidfield += "Please enter Desired Delivery Time" + "<br/>";
                        }
                    }
                    if (key === "hotweight") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Hot Weight / Roll Count" + "<br/>";
                        } else {
                            invalidfield += "Please enter Hot Weight / Roll Count" + "<br/>";
                        }
                    }
                    if (key === "exceptionreason") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Exception Reason" + "<br/>";
                        } else {
                            invalidfield += "Please enter Hot Exception Reason" + "<br/>";
                        }
                    }
                    if (key === "customerserviceemail") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Customer Service Email" + "<br/>";
                        } else {
                            invalidfield += "Please enter Customer Service Email" + "<br/>";
                        }
                    }
                    if (key === "afterhoursreceiver") {
                        if (invalidfield == '') {
                            invalidfield = "Please enter After Hours/Weekend Receiver Name" + "<br/>";
                        } else {
                            invalidfield += "Please enter After Hours/Weekend Receiver Name" + "<br/>";
                        }
                    }
                    if (key === "afterhoursphone") {
                        if(this.frmOrdersException.get('afterhoursphone').value === ''){
                            if (invalidfield == '') {
                                invalidfield = "Please enter Phone Number" + "<br/>";
                            } else {
                                invalidfield += "Please enter Phone Number" + "<br/>";
                            }
                        }

                        if(this.frmOrdersException.get('afterhoursphone').value !== ''){
                            if (invalidfield == '') {
                                invalidfield = "Please enter Phone Number with (XXX) XXX-XXXX format" + "<br/>";
                            } else {
                                invalidfield += "Please enter Phone Number with (XXX) XXX-XXXX format" + "<br/>";
                            }
                        }
                    }
                }

                if (key === 'requirerolls') {                    
                    if(this.frmOrdersException.get('requirerolls').value === true){
                        var arrSOLI = this.transferSOLIList.value;
                        debugger;
                        arrSOLI.forEach((k, index) => {
                            if(k.transfersalesorder == '') {
                                if (invalidfield == '') {
                                    invalidfield = `Please enter Transfer sales order ${index + 1}` + "<br/>";
                                } else {
                                    invalidfield += `Please enter Transfer sales order ${index + 1}` + "<br/>";
                                }
                            }
                            if(k.transferlineitem == '') {
                                if(invalidfield == '') {
                                    invalidfield = `Please enter Transfer Line Item ${index + 1}` + "<br/>";
                                } else {
                                    invalidfield += `Please enter Transfer Line Item ${index + 1}` + "<br/>";
                                }
                            }

                        });
                    }
                }

                if (key === "reqmodeshift") {
                    if(this.frmOrdersException.get('reqmodeshift').value === true){
                        if(this.frmOrdersException.get('modeshift').value == '') {
                            if(invalidfield == '') {
                                invalidfield = `Please enter Mode` + "<br/>";
                            } else {
                                invalidfield += `Please enter Mode` + "<br/>";
                            }
                        }

                        if(this.frmOrdersException.get('remainingbalanceshiftmode').value == '') {
                            if(invalidfield == '') {
                                invalidfield = `Please enter Mode for remaining balance` + "<br/>";
                            } else {
                                invalidfield += `Please enter Mode for remaining balance` + "<br/>";
                            }
                        }
                    }
                }

            });            
        }

       if(invalidfield !== '')
            this.alertService.showError(invalidfield);
    }

    CreateHotOrderException() {
        if (this.frmOrdersException.invalid) {
            this.Validation(this.frmOrdersException);
            return;
        }
        let orderExceptionModel = {
            //MillId: this.MillId,
            // Millnumber: this.frmMill.get('Millnumber').value,
            // Millname: this.frmMill.get('Millname').value,
            // Modifiedby: "jagdish"
        }

        let retvalue = this._HotOrderService.InsertUpdateMill(orderExceptionModel);
        retvalue.pipe(
            catchError(err => {
                this.alertService.showError("Error while creating record!!!");
                return of(null);
            })).subscribe((value: any) => {
                this.GetHotOrders();
                this.alertService.showSuccess("Record created successfully");
            })
    }

    UpdateMill() {
        if (this.frmOrdersException.invalid) {
            this.Validation(this.frmOrdersException);
            return;
        }

        let orderExceptionModel = {
            //MillId: this.MillId,
            // Millnumber: this.frmMill.get('Millnumber').value,
            // Millname: this.frmMill.get('Millname').value,
            // Modifiedby: "jagdish"
        }

        let retvalue = this._HotOrderService.InsertUpdateMill(orderExceptionModel);

        retvalue.pipe(
            catchError(err => {
                alert("Error while creating record!!!");
                return of(null);
            })).subscribe((value: any) => {
                setTimeout("", 1000);
                this.alertService.showSuccess("Record updated successfully");
            })
    }
}