import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'ordertypes',
  templateUrl: './otherconfig.component.html'
})
export class OtherConfigComponent implements OnInit {
    ngOnInit(): void {
       
    }
}