import { Component, OnInit, OnChanges, Inject } from '@angular/core';
import { of } from 'rxjs/observable/of';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute, UrlSegment  } from '@angular/router';
import { SharedService } from '../services/shared.service'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges{
  
  title = 'Meeting management system';
  
  config:any;
  baseurl:any;
  loggedIn : boolean; 
  isPreview :boolean;   
href : any;



  ngOnInit(){    
  var log : any ; 
  } 

  
receivedChildMessage: boolean;

  getMessage(message: boolean) {

  this.receivedChildMessage = message;

  }

  ngOnChanges(){
  
  }

  constructor(private _sharedService: SharedService, private router: Router, private activatedRoute: ActivatedRoute){  
  } 
}
