import { TestBed, inject } from '@angular/core/testing';
import { HotOrderService } from '../../services/HotOrder.service';
import { DataService } from '../../services/data.service';
import { Router } from '@angular/router';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import {
    HttpClientTestingModule,
    HttpTestingController
} from "@angular/common/http/testing";
import { of } from 'rxjs';

export class DataServiceMock {
    baseUrl: string;
    constructor() {//@Inject(dev) baseurl: any,
        this.baseUrl = "https://localhost:5001/api/";
    }
}

describe('HotOrderService', () => {
    let HotOrderService: HotOrderService;
    let httpTestingController: HttpTestingController;    

    beforeEach(() => {   
      TestBed.configureTestingModule({
        imports: [HttpClientTestingModule,HttpClientModule],
        providers: [HotOrderService, DataService, Router
            ,{ provide: DataService, useClass: DataServiceMock}
        ]
      });      
      httpTestingController = TestBed.get(HttpTestingController);      
    });

    it('should be created', () => {        
          HotOrderService = TestBed.get(HotOrderService); // Add this
          expect(HotOrderService).toBeTruthy();
    });

    it('should return a collection of mills', () => {
        const millsResponse = [
        {
            MillId: '1',
            Millnumber: '0211',
            Millname: 'Jane',
            Createdby: 'jagdish',
            Createddatetime: new Date(),
            Modifiedby: 'jagdish',
            Modifieddatetime: new Date()
        },
        {
            MillId: '2',
            Millnumber: '0211',
            Millname: 'Jane',
            Createdby: 'jagdish',
            Createddatetime: new Date(),
            Modifiedby: 'jagdish',
            Modifieddatetime: new Date()
        }
        ];

        let response;
        let param = {
        SortColumnName :"Millnumber",
        SortOrder :"ASC",
        PageSelected:0,
        PageSize:2
        };

        spyOn(HotOrderService, 'getMillsList').and.returnValue(of(millsResponse));        
        HotOrderService.getMillsList(param).subscribe(res => {
        response = res;
        });
        //console.log(response);
        //expect(response).not.toBeUndefined();
        expect(response).toEqual(millsResponse);
    });
         
});