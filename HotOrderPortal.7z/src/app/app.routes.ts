import { NgModule } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { APP_BASE_HREF } from '@angular/common'; 
import { LandingComponent } from './viewDetails/LandingPage.component'; 
import { AuthGuard } from '../security/auth.guard';
import { MeetingResolver } from '../services/Meetingresolver';
import { hotordersComponent } from './viewDetails/hotorders.component';
import { ErrorComponent } from './error/error.component';
import { insertupdatehotordersComponent } from './viewDetails/insertupdatehotorders.component'; 

const appRoutes: Routes = [
    { path: 'error', component: ErrorComponent},
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: LandingComponent},
    { path: 'hotorders', component: hotordersComponent},
    { path: 'insertupdatehotorders', component: insertupdatehotordersComponent},
    { path: 'administration', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)},        
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)], 
    exports: [RouterModule]
})

export class AppRoutingModule {
     
}