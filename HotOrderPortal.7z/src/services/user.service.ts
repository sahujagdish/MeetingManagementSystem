import { Injectable } from '@angular/core';
import {DataService} from '../services/data.service'; 
import { HttpClient } from '@angular/common/http';

export interface User {
    Username: string;
    Password: string;
}

export class UserSession {
    Username: string;
    Token: string;
}

@Injectable()
export class UserService {
    constructor(private dataService: DataService,private httpClient: HttpClient){
        
    }
      
    public authenticate(){ 

        return "api/protected/Authenticate";

      // var uss = new UserSession(); 
       //uss.Username = user.Username;x
       //uss.Token = "23432423432"
        
     // let auth : any;
      //auth = await this.dataService.post("api/protected/Authenticate",user) 

    //   let promise = await new Promise((resolve, reject) => {
    //     this.httpClient.post("http://localhost:49315/api/protected/Authenticate",user)
    //     .toPromise()
    //     .then(res => { // Success
    //         debugger;
    //         console.log(res);
    //         resolve();
    //       });
    // });
     //.pipe(map((res: Response) => resp = res.json()));
    
     //return promise;
        
     // return auth;
        //var auth0 = new BehaviorSubject<UserSession>(uss);
       //return auth0.asObservable(); 
    }
}

