import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from "rxjs";
import { StorageService } from './storage.service';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({providedIn: 'root'})
export class AuthInterceptor //implements HttpInterceptor 
{
  constructor(private storage: StorageService, private activeRoute: ActivatedRoute) {
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    const bareartoken = this.storage.$SessionStorageGet('globalAuth');
    if (this.storage.$SessionStorageGet('globalAuth') == '') {      
      const token = 'get token from Idaptave';      
      this.storage.$SessionStorageSet('globalAuth',token); 
      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
    } else {
      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${bareartoken.Token}`,
          'Content-Type': 'application/json'
        }
      });
    }
    return next.handle(req);
  }
}
