import { Injectable, Inject } from '@angular/core';
import { DataService } from './data.service';
//import { root,ConfigService } from '../services/config.service'; 
import { environment } from '../environments/environment';
import { observable, EMPTY, of } from 'rxjs';

@Injectable()
export class HotOrderService {
  baseUrl: any;

  constructor(private dataService: DataService) { // @Inject(root) env:any
    this.baseUrl = environment.API_URL;
  }

  public getMillsList(param:any) {  
    return of({});
   // return this.dataService.post(this.baseUrl + "/GetMillsDetail", param);
  }

  public getMills() {  
    return this.dataService.get(this.baseUrl + "/Mills");
  }

  public getMill(id: number) {
    return this.dataService.get(this.baseUrl + "/Mill/" + id);
  }

  public InsertUpdateMill(MillsModel) {   
    return this.dataService.post(this.baseUrl  + "/InsertUpdateMill", MillsModel);
  }

 public DeleteMill(id: number){
    return this.dataService.post(this.baseUrl  + "/DeleteMill/" + id,"");
  }

  public GetOrderTypesDetail(param:any) {  
    return this.dataService.post(this.baseUrl  + "/OrderTypesDetail", param);
  }

  public GetOrderTypes() {  
    return this.dataService.get(this.baseUrl + "/OrderTypes");
  }

  public GetOrderType(id: number) {
    return this.dataService.get(this.baseUrl + "/OrderType/" + id);
  }

  public InsertUpdateOrderType(OrderTypeModel) {   
    return this.dataService.post(this.baseUrl + "/InsertUpdateOrderType", OrderTypeModel);
  }

 public DeleteOrderType(id: number){
    return this.dataService.post(this.baseUrl + "/DeleteOrderType/" + id,"");
 }

 public getMailingList(param:any) {  
  return this.dataService.post(this.baseUrl + "/MailingList", param);
}

public getMailing(id: number) {
  return this.dataService.get(this.baseUrl + "/MailingList/" + id);
}

public InsertUpdateMailingList(MillsModel) {   
  return this.dataService.post(this.baseUrl + "/InsertUpdateMailingList", MillsModel);
}

public DeleteMailingList(id: number){
  return this.dataService.post(this.baseUrl + "/DeleteMailingList/" + id,"");
}

}


