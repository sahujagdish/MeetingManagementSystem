﻿using ShipmentException.BusinessModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;

namespace ShipmentException.Service
{
    public class ModelPaged<T>
    {
        public List<T> PagedDataModel;
        public Paging page;
    }

    public static class SortingandPagingInfo
    {
        public static IEnumerable<TSource> Paging<TSource>(this IEnumerable<TSource> source, LookupModel lookupModel, out Paging outModel)
        {
            Paging paging = new Paging();
            paging.TotalCount = source.Count();
            outModel = paging;          

            if (lookupModel.PageSize != 0)
            {
                if(lookupModel.PageSelected > 0)
                {
                    lookupModel.PageSelected -= 1; 
                }

                source = source.Skip(lookupModel.PageSelected * lookupModel.PageSize).Take(lookupModel.PageSize);
            }

            return source;
        }

        public static IQueryable<T> OrderByDynamic<T>(this IQueryable<T> query, string sortColumn, string descending)
        {
            // Dynamically creates a call like this: query.OrderBy(p => p.SortColumn)
            var parameter = Expression.Parameter(typeof(T), "p");

            string command = descending == "ASC" ? "OrderBy" : "OrderByDescending";

            //if (descending)
            //{
            //    command = "OrderByDescending";
            //}

            Expression resultExpression = null;

            var property = typeof(T).GetProperty(sortColumn);
            // this is the part p.SortColumn
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);

            // this is the part p => p.SortColumn
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);

            // finally, call the "OrderBy" / "OrderByDescending" method with the order by lamba expression
            resultExpression = Expression.Call(typeof(Queryable), command, new Type[] { typeof(T), property.PropertyType },
               query.Expression, Expression.Quote(orderByExpression));

            return query.Provider.CreateQuery<T>(resultExpression);
        }

        public static IOrderedQueryable<T> OrderBy<T>(this IQueryable<T> query, string memberName, string direction)
        {
            ParameterExpression[] typeParams = new ParameterExpression[] { Expression.Parameter(typeof(T), "") };


            System.Reflection.PropertyInfo pi = typeof(T).GetProperty(memberName);

            string methodName = direction == "ASC" ? "OrderBy" : "OrderByDescending";

            return (IOrderedQueryable<T>)query.Provider.CreateQuery(
                Expression.Call(
                    typeof(Queryable),
                    methodName,
                    new Type[] { typeof(T), pi.PropertyType },
                    query.Expression,
                    Expression.Lambda(Expression.Property(typeParams[0], pi), typeParams))
            );
        }

        public static IQueryable<T> SortBy<T>(this IQueryable<T> source,
                                      String propertyName,
                                      string direction)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (String.IsNullOrEmpty(propertyName)) return source;

            // Create a parameter to pass into the Lambda expression
            //(Entity => Entity.OrderByField).
            var parameter = Expression.Parameter(source.ElementType, ".");

            //  create the selector part, but support child properties (it works without . too)
            String[] childProperties = propertyName.Split('.');
            MemberExpression property = Expression.Property(parameter, childProperties[0]);
            for (int i = 1; i < childProperties.Length; i++)
            {
                property = Expression.Property(property, childProperties[i]);
            }

            LambdaExpression selector = Expression.Lambda(property, parameter);

            string methodName = direction == "ASC" ? "OrderBy" : "OrderByDescending";

            MethodCallExpression resultExp = Expression.Call(typeof(Queryable), methodName,
                                            new Type[] { source.ElementType, property.Type },
                                            source.Expression, Expression.Quote(selector));

            return source.Provider.CreateQuery<T>(resultExp);
        }
    }
}
