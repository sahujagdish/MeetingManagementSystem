﻿using Microsoft.EntityFrameworkCore;
using ShipmentException.BusinessModel;
using ShipmentException.Data.Model;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ShipmentException.Service
{
    public interface IMillsService
    {
       ModelPaged<MillsModel> GetMillsDetail(LookupModel LookupModel);
        MillsModel GetMill(int id);
        int InsertUpdateMill(MillsModel millsModel);
        List<CommonModel> GetMills();
        string DeleteMill(int id);
    }

    public class MillsService : IMillsService
    {
        ShipmentExceptionContext context;

        public MillsService(ShipmentExceptionContext _context)
        {
            context = _context;
        }

        public int Upload()
        {

            return 1;
        }


        public ModelPaged<MillsModel> GetMillsDetail(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var result = context.Mills.SortBy(lookupModel.SortColumnName, lookupModel.SortOrder).Select(x =>
               new MillsModel()
               {
                   MillId = x.Id,
                   Millnumber = x.Millnumber,
                   Millname = x.Millname,
                   Createdby = x.Createdby,
                   Createddatetime = x.Createddatetime,
                   Modifiedby = x.Modifiedby,
                   Modifieddatetime = x.Modifieddatetime
               }
            ).ToList();           

            var rr = new ModelPaged<MillsModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return rr;
        }

        public List<CommonModel> GetMills()
        {
            return context.Mills.Select(
              x => new CommonModel()
               {
                   Id = x.Id,
                   Name = x.Millname                 
               }
            ).ToList();
        }

        public MillsModel GetMill(int id)
        {
            
            return context.Mills.Where(x => x.Id == id).Select(x =>
                new MillsModel
                {
                    Millnumber = x.Millnumber,
                    Millname = x.Millname
                }).FirstOrDefault();
        }

        public int InsertUpdateMill(MillsModel millsModel)
        {
            Mills millsexists = context.Mills.Where(x => x.Id == millsModel.MillId).FirstOrDefault();
            if (millsexists != null)
            {
                millsexists.Millname = millsModel.Millname;
                millsexists.Millnumber = millsModel.Millnumber;
                millsexists.Modifiedby = millsModel.Modifiedby;
                millsexists.Modifieddatetime = DateTime.Now;
                context.Mills.Attach(millsexists);
                this.context.Entry(millsexists).State = EntityState.Modified;
            }
            else
            {
                context.Mills.Add(
                    new Mills()
                    {
                        Millname = millsModel.Millname,
                        Millnumber = millsModel.Millnumber,
                        Createdby = millsModel.Createdby,
                        Createddatetime = DateTime.Now,                                                
                    });
            }

            return context.SaveChanges();
        }

        public string DeleteMill(int id)
        {
            Mailinglist mailinglist = context.Mailinglist.Where(x => x.Millid == id).FirstOrDefault();
            if (mailinglist != null)
            {
                return "MailingExists";
            }

            Mills millsexists = context.Mills.Where(x => x.Id == id).FirstOrDefault();

            if (millsexists != null)
            {
                context.Mills.Remove(millsexists);
                return  Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }
    }
}
