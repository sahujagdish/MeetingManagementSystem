﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShipmentException.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Service.Tests
{
    [TestClass()]
    public class ShipmentServiceTests
    {
        [TestMethod()]
        public void GetShipmentExceptionTest()
        {

        }
    }
}

namespace ShipmentException.ServiceTests
{
    class ShipmentServiceTests
    {
    }
}
