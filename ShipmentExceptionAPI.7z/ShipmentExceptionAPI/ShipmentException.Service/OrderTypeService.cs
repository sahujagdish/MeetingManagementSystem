﻿using Microsoft.EntityFrameworkCore;
using ShipmentException.BusinessModel;
using ShipmentException.Data.Model;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ShipmentException.Service
{
    public interface IOrderTypeService
    {
            ModelPaged<OrderTypesModel> GetOrderTypeList(LookupModel LookupModel);
            OrderTypesModel GetOrderType(int id);
            int InsertUpdateOrderType(OrderTypesModel orderTypesModel);
            string DeleteOrderType(int id);
            List<CommonModel> GetOrderTypes();
    }
    public class OrderTypeService : IOrderTypeService
    {
        ShipmentExceptionContext context;
        public OrderTypeService(ShipmentExceptionContext _context)
        {
            context = _context;
        }

        public List<CommonModel> GetOrderTypes()
        {
            return context.Ordertypes.Select(
              x => new CommonModel()
              {
                  Id = x.Id,
                  Name = x.Ordertype
              }
            ).ToList();
        }

        public string DeleteOrderType(int id)
        {
            Mailinglist mailinglist = context.Mailinglist.Where(x => x.Ordertypeid == id).FirstOrDefault();
            if(mailinglist != null)
            {
                return "MailingExists";
            }
            Ordertypes ordertypesExists = context.Ordertypes.Where(x => x.Id == id).FirstOrDefault();

            if (ordertypesExists != null)
            {
                context.Ordertypes.Remove(ordertypesExists);
                return Convert.ToString(context.SaveChanges());

            } else {
                return "0";
            }
        }

        public ModelPaged<OrderTypesModel> GetOrderTypeList(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var result = context.Ordertypes.SortBy(lookupModel.SortColumnName, lookupModel.SortOrder).Select(x =>
                new OrderTypesModel
                {
                    OrdertypeId = x.Id,
                    Ordertype = x.Ordertype,
                    Createdby = x.Createdby,
                    Createddatetime = x.Createddatetime,
                    Modifiedby = x.Modifiedby,
                    Modifieddatetime = x.Modifieddatetime

                }).ToList();

            var ort = new ModelPaged<OrderTypesModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };

            return ort;
        }

        public OrderTypesModel GetOrderType(int id)
        {
            return context.Ordertypes.Where(x => x.Id == id).Select(x =>
               new OrderTypesModel
               {
                   OrdertypeId = x.Id,
                   Ordertype = x.Ordertype,
                   Createdby = x.Createdby,
                   Createddatetime = x.Createddatetime,
                   Modifiedby = x.Modifiedby,
                   Modifieddatetime = x.Modifieddatetime
               }).FirstOrDefault();
        }

        public int InsertUpdateOrderType(OrderTypesModel orderTypesModel)
        {
            Ordertypes ordertypesExists = context.Ordertypes.Where(x => x.Id == orderTypesModel.OrdertypeId).FirstOrDefault();
            if (ordertypesExists != null)
            {
                ordertypesExists.Ordertype = orderTypesModel.Ordertype;
                ordertypesExists.Modifiedby = orderTypesModel.Modifiedby;
                ordertypesExists.Modifieddatetime = DateTime.Now;
                context.Ordertypes.Attach(ordertypesExists);
                this.context.Entry(ordertypesExists).State = EntityState.Modified;
            }
            else
            {
                context.Ordertypes.Add(
                new Ordertypes()
                {
                    Ordertype = orderTypesModel.Ordertype,
                    Createdby = orderTypesModel.Createdby,
                    Createddatetime = DateTime.Now,
                });
            }

            return context.SaveChanges();
        }
    }
}
