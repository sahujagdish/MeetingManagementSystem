﻿using Microsoft.EntityFrameworkCore;
using ShipmentException.BusinessModel;
using ShipmentException.Data.Model;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipmentException.Service
{
    public interface IMailingListService
    {
        ModelPaged<MailingListModel> GetMailingList(LookupModel LookupModel);
        MailingListModel GetMailingList(int id);
        string InsertUpdateMailingList(MailingListModel MailingListModel);
        string DeleteMailingList(int id);
    }

    public class MailingListService : IMailingListService
    {
        ShipmentExceptionContext context;
        public MailingListService(ShipmentExceptionContext _context)
        {
            context = _context;
        }       

        public ModelPaged<MailingListModel> GetMailingList(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var result = context.Mailinglist.Include(x => x.Mill).Include(x => x.Ordertype)
                .Include(x => x.Mill).Include(x => x.Ordertype).Select(x =>
                new MailingListModel
                {
                    Id = x.Id,
                    OrdertypeId = x.Ordertypeid.Value,
                    Ordertype = x.Ordertype.Ordertype,
                    MillId = x.Millid.Value,
                    Executionteamdl = x.Executionteamdl,
                    Planningteamdl = x.Planningteamdl,
                    Millnumber = x.Mill.Millnumber,
                    Millname = x.Mill.Millname,
                    Createdby = x.Createdby,
                    Createddatetime = x.Createddatetime,
                    Modifiedby = x.Modifiedby,
                    Modifieddatetime = x.Modifieddatetime
                }).ToList();

            var ml = new ModelPaged<MailingListModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return ml;
        }

        public MailingListModel GetMailingList(int id)
        {
            return context.Mailinglist.Where(x => x.Id == id).Select(x =>
               new MailingListModel
               {
                   Id = x.Id,
                   OrdertypeId = x.Ordertypeid.Value,
                   Ordertype = x.Ordertype.Ordertype,
                   MillId = x.Millid.Value,
                   Executionteamdl = x.Executionteamdl,
                   Planningteamdl = x.Planningteamdl,
                   Millnumber = x.Mill.Millnumber,
                   Millname = x.Mill.Millname,
                   Createdby = x.Createdby,
                   Createddatetime = x.Createddatetime,
                   Modifiedby = x.Modifiedby,
                   Modifieddatetime = x.Modifieddatetime
               }).FirstOrDefault();
        }

        public string InsertUpdateMailingList(MailingListModel MailingListModel)
        {
            Mailinglist MailingListExists = context.Mailinglist.Where(x => x.Id == MailingListModel.Id).FirstOrDefault();
            
            Mailinglist similarListInOtherId = context.Mailinglist
                    .Where(x => (x.Ordertypeid == MailingListModel.OrdertypeId && x.Millid == MailingListModel.MillId && x.Id != MailingListModel.Id)).FirstOrDefault();

            if (similarListInOtherId != null)
            {
                return "CombinationAllreadyExists";
            }

            if (MailingListExists != null)
            {
                MailingListExists.Ordertypeid = MailingListModel.OrdertypeId;
                MailingListExists.Millid = MailingListModel.MillId;
                MailingListExists.Executionteamdl = MailingListModel.Executionteamdl;
                MailingListExists.Planningteamdl = MailingListModel.Planningteamdl;
                MailingListExists.Modifiedby = MailingListModel.Modifiedby;
                MailingListExists.Modifieddatetime = DateTime.Now;
                context.Mailinglist.Attach(MailingListExists);
                context.Entry(MailingListExists).State = EntityState.Modified;
            }
            else
            {
                context.Mailinglist.Add(
                new Mailinglist()
                {
                    Ordertypeid = MailingListModel.OrdertypeId,
                    Millid = MailingListModel.MillId,
                    Executionteamdl = MailingListModel.Executionteamdl,
                    Planningteamdl = MailingListModel.Planningteamdl,
                    Createdby = MailingListModel.Createdby,
                    Createddatetime = DateTime.Now,
                });
            }

            return Convert.ToString(context.SaveChanges());
        }

        public string DeleteMailingList(int id)
        {
            Mailinglist MailingListExists = context.Mailinglist.Where(x => x.Id == id).FirstOrDefault();

            if (MailingListExists != null)
            {
                context.Mailinglist.Remove(MailingListExists);
                return Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }
    }
}
