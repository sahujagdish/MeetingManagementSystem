﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ShipmentException.Data.Migrations
{
    public partial class change_createddate_to_createddatetime : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "modifieddate",
                table: "ordertypes",
                newName: "modifieddatetime");

            migrationBuilder.RenameColumn(
                name: "createdate",
                table: "ordertypes",
                newName: "createdatetime");

            migrationBuilder.RenameColumn(
                name: "modifieddate",
                table: "mills",
                newName: "modifieddatetime");

            migrationBuilder.RenameColumn(
                name: "createddate",
                table: "mills",
                newName: "createddatetime");

            migrationBuilder.RenameColumn(
                name: "modifieddate",
                table: "mailinglist",
                newName: "modifieddatetime");

            migrationBuilder.RenameColumn(
                name: "createddate",
                table: "mailinglist",
                newName: "createddatetime");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "modifieddatetime",
                table: "ordertypes",
                newName: "modifieddate");

            migrationBuilder.RenameColumn(
                name: "createdatetime",
                table: "ordertypes",
                newName: "createdate");

            migrationBuilder.RenameColumn(
                name: "modifieddatetime",
                table: "mills",
                newName: "modifieddate");

            migrationBuilder.RenameColumn(
                name: "createddatetime",
                table: "mills",
                newName: "createddate");

            migrationBuilder.RenameColumn(
                name: "modifieddatetime",
                table: "mailinglist",
                newName: "modifieddate");

            migrationBuilder.RenameColumn(
                name: "createddatetime",
                table: "mailinglist",
                newName: "createddate");
        }
    }
}
