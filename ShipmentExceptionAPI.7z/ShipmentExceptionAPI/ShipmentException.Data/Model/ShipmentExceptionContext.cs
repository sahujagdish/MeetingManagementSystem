﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using ShipmentException.Data.Model.Entity;
using ShipmentException.Data.Model.Mapping;

namespace ShipmentException.Data.Model
{
    public partial class ShipmentExceptionContext : DbContext
    {
        public ShipmentExceptionContext()
        {
        }

        public ShipmentExceptionContext(DbContextOptions<ShipmentExceptionContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Mailinglist> Mailinglist { get; set; }
        public virtual DbSet<Mills> Mills { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<Ordertypes> Ordertypes { get; set; }
        public virtual DbSet<Shipmentdetails> Shipmentdetails { get; set; }
        public virtual DbSet<Shipmentexception> Shipmentexception { get; set; }
        public virtual DbSet<Shipmentordermapping> Shipmentordermapping { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
               //optionsBuilder.UseSqlServer(Setting.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.ApplyConfiguration(new MailinglistMap());
            modelBuilder.ApplyConfiguration(new MillsMap());
            modelBuilder.ApplyConfiguration(new OrdersMap());
            modelBuilder.ApplyConfiguration(new OrdertypesMap());
            modelBuilder.ApplyConfiguration(new OrdersMap());
            modelBuilder.ApplyConfiguration(new OrdersMap());
            modelBuilder.ApplyConfiguration(new OrdersMap());

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
