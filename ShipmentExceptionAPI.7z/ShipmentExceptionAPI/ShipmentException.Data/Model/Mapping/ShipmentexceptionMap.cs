﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data.Model.Mapping
{
    public class ShipmentexceptionMap : IEntityTypeConfiguration<Shipmentexception>
    {
        public void Configure(EntityTypeBuilder<Shipmentexception> builder)
        {
            builder.ToTable("shipmentexception");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())");

            builder.Property(e => e.ExceptionNumber).HasMaxLength(20);

            builder.Property(e => e.Isactive)
                .IsRequired()
                .HasColumnName("isactive")
                .HasDefaultValueSql("((1))");

            builder.Property(e => e.Status)
                .IsRequired()
                .HasColumnName("status")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Updatedby)
                .HasColumnName("updatedby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Updateddate)
                .HasColumnName("updateddate")
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())");
        }
    }
}
