﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data.Model.Mapping
{
    public class ShipmentordermappingMap : IEntityTypeConfiguration<Shipmentordermapping>
    {
        public void Configure(EntityTypeBuilder<Shipmentordermapping> builder)
        {
            builder.ToTable("shipmentordermapping");

            builder.HasIndex(e => e.Orderid);

            builder.HasIndex(e => e.Shipmentid);

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Orderid).HasColumnName("orderid");

            builder.Property(e => e.Shipmentid).HasColumnName("shipmentid");

            builder.HasOne(d => d.Order)
                .WithMany(p => p.Shipmentordermapping)
                .HasForeignKey(d => d.Orderid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_shipmentordermapping_orders");

            builder.HasOne(d => d.Shipment)
                .WithMany(p => p.Shipmentordermapping)
                .HasForeignKey(d => d.Shipmentid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_shipmentordermapping_shipmentdetails");
        }
    }
}
