﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data.Model.Mapping
{
    public class ShipmentdetailsMap : IEntityTypeConfiguration<Shipmentdetails>
    {
        public void Configure(EntityTypeBuilder<Shipmentdetails> builder)
        {
            builder.ToTable("shipmentdetails");

            builder.HasIndex(e => e.Shipmentexceptionid);

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Carrier)
                .HasColumnName("carrier")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime");

            builder.Property(e => e.Currentdate)
                .HasColumnName("currentdate")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Currentshipmentstatus)
                .IsRequired()
                .HasColumnName("currentshipmentstatus")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Currenttime)
                .HasColumnName("currenttime")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Domestic).HasColumnName("domestic");

            builder.Property(e => e.Isactive)
                .IsRequired()
                .HasColumnName("isactive")
                .HasDefaultValueSql("((1))");

            builder.Property(e => e.Message)
                .HasColumnName("message")
                .HasMaxLength(500)
                .IsUnicode(false);

            builder.Property(e => e.Shipmentexceptionid).HasColumnName("shipmentexceptionid");

            builder.Property(e => e.Shipmentnumber).HasColumnName("shipmentnumber");

            builder.Property(e => e.Shippingcondition)
                .HasColumnName("shippingcondition")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Updatedby)
                .HasColumnName("updatedby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Updateddate)
                .HasColumnName("updateddate")
                .HasColumnType("datetime");

            builder.HasOne(d => d.Shipmentexception)
                .WithMany(p => p.Shipmentdetails)
                .HasForeignKey(d => d.Shipmentexceptionid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_shipmentdetails_shipmentexception");
        }
    }
}
