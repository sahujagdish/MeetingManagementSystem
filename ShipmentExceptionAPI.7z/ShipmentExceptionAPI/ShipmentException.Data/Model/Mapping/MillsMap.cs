﻿using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ShipmentException.Data.Model.Mapping
{
    public class MillsMap : IEntityTypeConfiguration<Mills>
    {
        public MillsMap()
        {
           
        }

        public void Configure(EntityTypeBuilder<Mills> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createddatetime)
                .HasColumnName("createddatetime")
                .HasColumnType("datetime")
                .IsRequired();

            builder.Property(e => e.Millname)
                .IsRequired()
                .HasColumnName("millname")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Millnumber)
                .IsRequired()
                .HasColumnName("millnumber")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                .HasColumnName("modifiedby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddatetime)
                .HasColumnName("modifieddatetime")
                .HasColumnType("datetime")
                ;

            builder.ToTable("mills");
        }
    }
}
