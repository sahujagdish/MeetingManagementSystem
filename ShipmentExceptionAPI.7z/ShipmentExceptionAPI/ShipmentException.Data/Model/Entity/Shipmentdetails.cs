﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Shipmentdetails
    {
        public Shipmentdetails()
        {
            Shipmentordermapping = new HashSet<Shipmentordermapping>();
        }

        public int Id { get; set; }
        public int Shipmentexceptionid { get; set; }
        public int? Shipmentnumber { get; set; }
        public bool Domestic { get; set; }
        public string Shippingcondition { get; set; }
        public string Carrier { get; set; }
        public string Currentshipmentstatus { get; set; }
        public string Currentdate { get; set; }
        public string Currenttime { get; set; }
        public string Message { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Updateddate { get; set; }
        public bool? Isactive { get; set; }

        public virtual Shipmentexception Shipmentexception { get; set; }
        public virtual ICollection<Shipmentordermapping> Shipmentordermapping { get; set; }
    }
}
