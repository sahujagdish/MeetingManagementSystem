﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Shipmentordermapping
    {
        public int Id { get; set; }
        public int Shipmentid { get; set; }
        public int Orderid { get; set; }

        public virtual Orders Order { get; set; }
        public virtual Shipmentdetails Shipment { get; set; }
    }
}
