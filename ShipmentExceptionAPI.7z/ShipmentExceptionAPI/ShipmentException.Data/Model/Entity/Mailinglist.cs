﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Mailinglist
    {
        public int Id { get; set; }
        public int? Millid { get; set; }
        public int? Ordertypeid { get; set; }
        public string Planningteamdl { get; set; }
        public string Executionteamdl { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddatetime { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddatetime { get; set; }

        public virtual Mills Mill { get; set; }
        public virtual Ordertypes Ordertype { get; set; }
    }
}
