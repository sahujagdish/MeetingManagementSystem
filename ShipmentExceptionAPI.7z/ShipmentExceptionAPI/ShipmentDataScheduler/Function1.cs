using System;
using System.Collections.Generic;
using System.Net.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Build.Utilities;
using Microsoft.Extensions.Logging;

namespace ShipmentDataScheduler
{

    public class LookupModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public static class Function1
    {
        [FunctionName("Function1")]
        public static async void Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log)
        {
            HttpClient newClient = new HttpClient();
            HttpRequestMessage newRequest = new HttpRequestMessage(HttpMethod.Get, "https://localhost:5001/api/v1/Mills");

            //Read Server Response
           // HttpResponseMessage response = newRequest.CreateResponse();

            HttpResponseMessage response = await newClient.SendAsync(newRequest);


            List<LookupModel> mills = new List<LookupModel>();

           List<LookupModel> a = await response.Content.ReadAsAsync<List<LookupModel>>();

            //Return Mpn status 


            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
        }
    }
}
