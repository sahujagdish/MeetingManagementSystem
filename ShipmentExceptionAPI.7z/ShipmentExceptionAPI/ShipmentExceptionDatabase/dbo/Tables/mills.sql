﻿CREATE TABLE [dbo].[mills] (
    [id]          INT           IDENTITY (1, 1) NOT NULL,
    [millnumber]  VARCHAR (10)  NOT NULL,
    [millname]    VARCHAR (200) NOT NULL,
    [createdby]   VARCHAR (200) NOT NULL,
    [createddate] DATETIME      NOT NULL,
    [updatedby]   VARCHAR (200) NULL,
    [updateddate] DATETIME      NULL,
    [isactive]    BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_mills] PRIMARY KEY CLUSTERED ([id] ASC)
);

