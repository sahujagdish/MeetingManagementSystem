﻿CREATE TABLE [dbo].[shipmentdetails] (
    [id]                    INT           IDENTITY (1, 1) NOT NULL,
    [shipmentexceptionid]   INT           NOT NULL,
    [shipmentnumber]        INT           NULL,
    [domestic]              BIT           NOT NULL,
    [shippingcondition]     VARCHAR (200) NULL,
    [carrier]               VARCHAR (200) NULL,
    [currentshipmentstatus] VARCHAR (200) NOT NULL,
    [currentdate]           VARCHAR (20)  NULL,
    [currenttime]           VARCHAR (20)  NULL,
    [message]               VARCHAR (500) NULL,
    [createdby]             VARCHAR (200) NOT NULL,
    [createddate]           DATETIME      NOT NULL,
    [updatedby]             VARCHAR (200) NULL,
    [updateddate]           DATETIME      NULL,
    [isactive]              BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_shipmentdetails] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_shipmentdetails_shipmentexception] FOREIGN KEY ([shipmentexceptionid]) REFERENCES [dbo].[shipmentexception] ([id])
);


GO
CREATE NONCLUSTERED INDEX [IX_shipmentdetails_shipmentexceptionid]
    ON [dbo].[shipmentdetails]([shipmentexceptionid] ASC);

