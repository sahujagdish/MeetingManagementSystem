﻿CREATE TABLE [dbo].[roleconfig] (
    [id]               INT           IDENTITY (1, 1) NOT NULL,
    [roleid]           INT           NOT NULL,
    [millid]           INT           NOT NULL,
    [domestic]         BIT           NULL,
    [emails]           VARCHAR (MAX) NULL,
    [additionalemails] VARCHAR (MAX) NULL,
    [createdby]        VARCHAR (200) NOT NULL,
    [createddate]      DATETIME      NOT NULL,
    [updatedby]        VARCHAR (200) NULL,
    [updateddate]      DATETIME      NULL,
    [isactive]         BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_roleconfig] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_roleconfig_mills] FOREIGN KEY ([millid]) REFERENCES [dbo].[mills] ([id]),
    CONSTRAINT [FK_roleconfig_roles] FOREIGN KEY ([roleid]) REFERENCES [dbo].[roles] ([id])
);


GO
CREATE NONCLUSTERED INDEX [IX_roleconfig_millid]
    ON [dbo].[roleconfig]([millid] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_roleconfig_roleid]
    ON [dbo].[roleconfig]([roleid] ASC);

