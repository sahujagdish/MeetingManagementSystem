﻿CREATE TABLE [dbo].[shipmentexception] (
    [id]              INT           IDENTITY (1, 1) NOT NULL,
    [ExceptionNumber] NVARCHAR (20) NULL,
    [status]          VARCHAR (20)  NOT NULL,
    [createdby]       VARCHAR (200) NOT NULL,
    [createddate]     DATETIME      DEFAULT (getdate()) NOT NULL,
    [updatedby]       VARCHAR (200) NULL,
    [updateddate]     DATETIME      DEFAULT (getdate()) NULL,
    [isactive]        BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_shipmentexception] PRIMARY KEY CLUSTERED ([id] ASC)
);

