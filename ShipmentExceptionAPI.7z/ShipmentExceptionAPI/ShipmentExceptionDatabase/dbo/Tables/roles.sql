﻿CREATE TABLE [dbo].[roles] (
    [id]          INT           IDENTITY (1, 1) NOT NULL,
    [rolename]    VARCHAR (200) NOT NULL,
    [createdby]   VARCHAR (200) NOT NULL,
    [createddate] DATETIME      NOT NULL,
    [updatedby]   VARCHAR (200) NULL,
    [updateddate] DATETIME      NULL,
    [isactive]    BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_roles] PRIMARY KEY CLUSTERED ([id] ASC)
);

