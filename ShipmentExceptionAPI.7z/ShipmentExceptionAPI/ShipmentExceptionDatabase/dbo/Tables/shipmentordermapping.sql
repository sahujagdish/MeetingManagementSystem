﻿CREATE TABLE [dbo].[shipmentordermapping] (
    [id]         INT IDENTITY (1, 1) NOT NULL,
    [shipmentid] INT NOT NULL,
    [orderid]    INT NOT NULL,
    CONSTRAINT [PK_shipmentordermapping] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_shipmentordermapping_orders] FOREIGN KEY ([orderid]) REFERENCES [dbo].[orders] ([id]),
    CONSTRAINT [FK_shipmentordermapping_shipmentdetails] FOREIGN KEY ([shipmentid]) REFERENCES [dbo].[shipmentdetails] ([id])
);


GO
CREATE NONCLUSTERED INDEX [IX_shipmentordermapping_orderid]
    ON [dbo].[shipmentordermapping]([orderid] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_shipmentordermapping_shipmentid]
    ON [dbo].[shipmentordermapping]([shipmentid] ASC);

