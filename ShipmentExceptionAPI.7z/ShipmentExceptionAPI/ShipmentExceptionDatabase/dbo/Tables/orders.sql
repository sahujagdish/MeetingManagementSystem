﻿CREATE TABLE [dbo].[orders] (
    [id]                     INT           IDENTITY (1, 1) NOT NULL,
    [ordernumber]            VARCHAR (20)  NOT NULL,
    [lineitemnumber]         VARCHAR (10)  NOT NULL,
    [indicator]              VARCHAR (20)  NOT NULL,
    [message]                VARCHAR (200) NULL,
    [materialnumber]         VARCHAR (50)  NULL,
    [gradedescription]       VARCHAR (500) NULL,
    [shippingfacilitynumber] VARCHAR (10)  NULL,
    [shippingfacilityname]   VARCHAR (50)  NULL,
    [soldtoid]               VARCHAR (20)  NULL,
    [soldtocustomername]     VARCHAR (200) NULL,
    [shiptoid]               VARCHAR (20)  NULL,
    [shiptocustomername]     VARCHAR (200) NULL,
    [shiptocity]             VARCHAR (200) NULL,
    [shiptostate]            VARCHAR (20)  NULL,
    [createdby]              VARCHAR (200) NOT NULL,
    [createddate]            DATETIME      NOT NULL,
    [updatedby]              VARCHAR (200) NULL,
    [updateddate]            DATETIME      NULL,
    [isactive]               BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_orders] PRIMARY KEY CLUSTERED ([id] ASC)
);

