using Microsoft.EntityFrameworkCore.Sqlite;
using Microsoft.EntityFrameworkCore;
using Moq;
using ShipmentException.Data.Model;
using ShipmentException.Data.Model.Entity;
using ShipmentException.Service;
using System;
using Xunit;
using Xunit.Extensions.Ordering;
using Microsoft.Data.Sqlite;
using ShipmentException.BusinessModel;

[assembly: CollectionBehavior(DisableTestParallelization = true)]
[assembly: TestCollectionOrderer("Xunit.Extensions.Ordering.CollectionOrderer", "Xunit.Extensions.Ordering")]
namespace ShipmentExceptionTestProject
{       
    [TestCaseOrderer("Xunit.Extensions.Ordering.TestCaseOrderer", "Xunit.Extensions.Ordering")]    
    public class RoleMillsServiceTests
    {
        ShipmentExceptionContext context;

        public RoleMillsServiceTests()
        {
            var factory = new ConnectionFactory();
            
            context = factory.CreateContextForSQLite();

            Seed_RoleMillsService_Test_Data(context);
        }

        [Fact,Order(1)]
        public void GetMills_Test_ExpectedBehavior() {           

            var query = new MillsService(context); 
            //var result = query.GetMillList();
            //Assert.Equal(3, result.Count);
        }  

        private void Seed_RoleMillsService_Test_Data(ShipmentExceptionContext context)
        {   
            var mills = new[]
            {
                new Mills{Millnumber = "7108", Millname="Cedar River", Createddatetime=DateTime.Now, Createdby ="Jagdish" },
                new Mills{Millnumber = "0660", Millname="Augusta", Createddatetime=DateTime.Now, Createdby ="Jagdish" },
                 new Mills{Millnumber = "0661", Millname="Reigelwood", Createddatetime=DateTime.Now, Createdby ="Jagdish" }
            };

            context.Mills.AddRange(mills);
            context.SaveChanges();
        }
    }
}
