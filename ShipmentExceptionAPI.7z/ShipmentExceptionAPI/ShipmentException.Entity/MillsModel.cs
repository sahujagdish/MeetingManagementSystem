﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.BusinessModel
{
    public class MillsModel : BaseModel
    {
        public int MillId { get; set; }
        public string Millnumber { get; set; }
        public string Millname { get; set; }
       
    }   
}
