using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ShipmentException.Data;
//using ShipmentException.Data.Model;
using ShipmentExceptionAPI.Helper;
using Serilog;
using ShipmentException.Service;
using ShipmentException.Data.Model;
//using ShipmentException.Data.Model;
//using ShipmentException.Service.Repository;

namespace ShipmentExceptionAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddDbContext<ShipmentExceptionContext>(options =>
                        options.UseSqlServer(Configuration.GetValue<string>("sqlConString")),
                      //  options.UseSqlServer(Configuration["ConnectionStrings:sqlConString"]),
              ServiceLifetime.Transient);

            var context = services.BuildServiceProvider()
                      .GetService<ShipmentExceptionContext>();

            services.AddTransient<IMillsService, MillsService>();
            services.AddTransient<IOrderTypeService, OrderTypeService>();
            services.AddTransient<IMailingListService, MailingListService>();
            services.AddScoped<CheckAuthToken>();
            services.AddControllers();

           


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(options => options.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader());

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();                
            }            

            app.UseHttpsRedirection();

            app.UseSerilogRequestLogging();

            app.UseRouting();

            app.UseAuthorization();

           

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
