﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipmentException.BusinessModel;
using ShipmentException.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShipmentExceptionAPI.Controllers
{
    [ApiController]
    [Route("api/v1")]
    public class MailingListController : ControllerBase
    {
        IMailingListService mailingListService;
        ILogger<MailingListController> logger;
        public MailingListController(IMailingListService _mailingListService, ILogger<MailingListController> _logger, IConfiguration config)
        {
            mailingListService = _mailingListService;
            logger = _logger;
        }

        [HttpPost]
        [Route("MailingList")]
        public IActionResult GetMailingList([FromBody] LookupModel lookupModel)
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(mailingListService.GetMailingList(lookupModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetMailingList");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("MailingList/{id}")]
        public IActionResult GetMailingList(int id)
        {
            try
            {
                return Ok(mailingListService.GetMailingList(id));                 
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetMailingList");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("InsertUpdateMailingList")]
        public IActionResult InsertUpdateMailingList(MailingListModel MailingListModel)
        {
            try
            {
               return Ok(JsonConvert.SerializeObject(mailingListService.InsertUpdateMailingList(MailingListModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "InsertUpdateMailingList");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("DeleteMailingList")]
        public IActionResult DeleteMailingList(int id)
        {
            string retvalue = "";
            try
            {
                return Ok(mailingListService.DeleteMailingList(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteMailingList");
                return StatusCode(500, "internal server error");
            }
        }
    }
}

