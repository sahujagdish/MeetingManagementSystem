﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipmentException.BusinessModel;
using ShipmentException.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShipmentExceptionAPI.Controllers
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    public class OrderTypesController : ControllerBase
    {
        IOrderTypeService orderTypeService;
        ILogger<OrderTypesController> logger;
        public OrderTypesController(IOrderTypeService _orderTypeService, ILogger<OrderTypesController> _logger, IConfiguration config)
        {
            orderTypeService = _orderTypeService;
            logger = _logger;
        }
       
        [Route("OrderTypes")]
        public IActionResult GetOrderTypes()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(orderTypeService.GetOrderTypes()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOrderTypes");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("OrderTypesDetail")]
        public IActionResult GetOrderTypesDetail([FromBody] LookupModel lookupModel)
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(orderTypeService.GetOrderTypeList(lookupModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOrderTypes");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("OrderType/{id}")]
        public OrderTypesModel GetOrderType(int id)
        {
            OrderTypesModel OrderTypesModel = new OrderTypesModel();
            try
            {
                OrderTypesModel = orderTypeService.GetOrderType(id);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOrderType");
            }

            return OrderTypesModel;
        }

        [HttpPost]
        [Route("InsertUpdateOrderType")]
        public IActionResult InsertUpdateOrderType(OrderTypesModel OrderTypesModel)
        {
            int retvalue = 0;
            try
            {
               return  Ok(JsonConvert.SerializeObject(orderTypeService.InsertUpdateOrderType(OrderTypesModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "InsertUpdateOrderType");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("DeleteOrderType")]
        public IActionResult DeleteOrderType(int id)
        {            
            try
            {
                return Ok(orderTypeService.DeleteOrderType(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteOrderType");
                return StatusCode(500, "internal server error");
            }
        }
    }
}

