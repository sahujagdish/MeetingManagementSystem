﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShipmentExceptionAPI.Helper
{
    public class CheckAuthToken : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var req = actionContext.HttpContext.Request;
            var header = req.Headers;
            //if (req.RequestUri.AbsolutePath != "/api/protected/Authenticate")
            //{
            //    var token = header.Authorization;
            //    if (token == null)
            //    {
            //        var output = new { Status = "UnAthorised token" };
            //        actionContext.Response = new HttpResponseMessage
            //        {
            //            Content = new StringContent(JsonConvert.SerializeObject(output), Encoding.UTF8, "application/json"),
            //            StatusCode = HttpStatusCode.BadRequest
            //        };
            //    }
            //}
            base.OnActionExecuting(actionContext);
        }
    }
}
