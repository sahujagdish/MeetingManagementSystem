﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;

namespace ShipmentExceptionAPI.Helper
{
    public class Common
    {
        public static bool ProcessFormFile<T>(IFormFile formFile,
               string[] permittedExtensions,
                long sizeLimit)
        {
            var fieldDisplayName = string.Empty;           

            if (formFile.Length == 0)
            {
                return false;
            }

            if (formFile.Length > sizeLimit)
            {
                return false;
            }

            if (!IsValidFileExtension(formFile.FileName, permittedExtensions))
            {
                return false;
            }

            return true;
        }

        private static bool IsValidFileExtension(string fileName, string[] permittedExtensions)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return false;
            }

            var ext = Path.GetExtension(fileName).ToLowerInvariant();

            if (string.IsNullOrEmpty(ext) || !permittedExtensions.Contains(ext))
            {
                return false;
            }

            return true;
        }


    }
}

