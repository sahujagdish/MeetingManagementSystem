﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data
{
    public static class Setting
    {
        public static string ConnectionString { get; set; }
    }
}
