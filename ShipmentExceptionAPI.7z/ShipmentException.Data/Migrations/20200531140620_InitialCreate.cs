﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ShipmentException.Data.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "mills",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    millnumber = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    millname = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mills", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "orders",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ordernumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    lineitemnumber = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    indicator = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    message = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    materialnumber = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    gradedescription = table.Column<string>(unicode: false, maxLength: 500, nullable: true),
                    shippingfacilitynumber = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    shippingfacilityname = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    soldtoid = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    soldtocustomername = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    shiptoid = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    shiptocustomername = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    shiptocity = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    shiptostate = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    createdby = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    updatedby = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    updateddate = table.Column<DateTime>(type: "datetime", nullable: true),
                    isactive = table.Column<bool>(nullable: false, defaultValueSql: "((1))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orders", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ordertypes",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ordertype = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createdate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ordertypes", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Shipmentexception",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ExceptionNumber = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Createdby = table.Column<string>(nullable: true),
                    Createddate = table.Column<DateTime>(nullable: false),
                    Updatedby = table.Column<string>(nullable: true),
                    Updateddate = table.Column<DateTime>(nullable: true),
                    Isactive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shipmentexception", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "mailinglist",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    millid = table.Column<int>(nullable: true),
                    ordertypeid = table.Column<int>(nullable: true),
                    planningteamdl = table.Column<string>(unicode: false, maxLength: 500, nullable: true),
                    executionteamdl = table.Column<string>(unicode: false, maxLength: 500, nullable: true),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mailinglist", x => x.id);
                    table.ForeignKey(
                        name: "FK_mailinglist_mills",
                        column: x => x.millid,
                        principalTable: "mills",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_mailinglist_ordertypes",
                        column: x => x.ordertypeid,
                        principalTable: "ordertypes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Shipmentdetails",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Shipmentexceptionid = table.Column<int>(nullable: false),
                    Shipmentnumber = table.Column<int>(nullable: true),
                    Domestic = table.Column<bool>(nullable: false),
                    Shippingcondition = table.Column<string>(nullable: true),
                    Carrier = table.Column<string>(nullable: true),
                    Currentshipmentstatus = table.Column<string>(nullable: true),
                    Currentdate = table.Column<string>(nullable: true),
                    Currenttime = table.Column<string>(nullable: true),
                    Message = table.Column<string>(nullable: true),
                    Createdby = table.Column<string>(nullable: true),
                    Createddate = table.Column<DateTime>(nullable: false),
                    Updatedby = table.Column<string>(nullable: true),
                    Updateddate = table.Column<DateTime>(nullable: true),
                    Isactive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shipmentdetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Shipmentdetails_Shipmentexception_Shipmentexceptionid",
                        column: x => x.Shipmentexceptionid,
                        principalTable: "Shipmentexception",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Shipmentordermapping",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Shipmentid = table.Column<int>(nullable: false),
                    Orderid = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shipmentordermapping", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Shipmentordermapping_orders_Orderid",
                        column: x => x.Orderid,
                        principalTable: "orders",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Shipmentordermapping_Shipmentdetails_Shipmentid",
                        column: x => x.Shipmentid,
                        principalTable: "Shipmentdetails",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_mailinglist_millid",
                table: "mailinglist",
                column: "millid");

            migrationBuilder.CreateIndex(
                name: "IX_mailinglist_ordertypeid",
                table: "mailinglist",
                column: "ordertypeid");

            migrationBuilder.CreateIndex(
                name: "IX_Shipmentdetails_Shipmentexceptionid",
                table: "Shipmentdetails",
                column: "Shipmentexceptionid");

            migrationBuilder.CreateIndex(
                name: "IX_Shipmentordermapping_Orderid",
                table: "Shipmentordermapping",
                column: "Orderid");

            migrationBuilder.CreateIndex(
                name: "IX_Shipmentordermapping_Shipmentid",
                table: "Shipmentordermapping",
                column: "Shipmentid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "mailinglist");

            migrationBuilder.DropTable(
                name: "Shipmentordermapping");

            migrationBuilder.DropTable(
                name: "mills");

            migrationBuilder.DropTable(
                name: "ordertypes");

            migrationBuilder.DropTable(
                name: "orders");

            migrationBuilder.DropTable(
                name: "Shipmentdetails");

            migrationBuilder.DropTable(
                name: "Shipmentexception");
        }
    }
}
