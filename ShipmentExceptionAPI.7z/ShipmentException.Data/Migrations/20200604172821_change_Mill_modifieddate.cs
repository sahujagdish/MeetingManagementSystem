﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ShipmentException.Data.Migrations
{
    public partial class change_Mill_modifieddate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {           

            migrationBuilder.AlterColumn<DateTime>(
                name: "modifieddate",
                table: "mills",
                type: "datetime",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "modifieddate",
                table: "mills",
                newName: "updateddate");

            migrationBuilder.RenameColumn(
                name: "modifiedby",
                table: "mills",
                newName: "updatedby");

            migrationBuilder.AlterColumn<DateTime>(
                name: "updateddate",
                table: "mills",
                type: "datetime",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime",
                oldNullable: true);
        }
    }
}
