﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data.Model.Mapping
{
    public class OrdertypesMap : IEntityTypeConfiguration<Ordertypes>
    {
        public void Configure(EntityTypeBuilder<Ordertypes> builder)
        {
            builder.ToTable("ordertypes");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createddatetime)
                        .IsRequired()
                        .HasColumnName("createdatetime")
                        .HasColumnType("datetime");

            builder.Property(e => e.Createdby)
                        .IsRequired()
                        .HasColumnName("createdby")
                        .HasMaxLength(50)
                        .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                        .HasColumnName("modifiedby")
                        .HasMaxLength(50)
                        .IsUnicode(false);

            builder.Property(e => e.Modifieddatetime)
                        .HasColumnName("modifieddatetime")
                        .HasColumnType("datetime");

            builder.Property(e => e.Ordertype)
                        .IsRequired()
                        .HasColumnName("ordertype")
                        .HasMaxLength(10)
                        .IsUnicode(false);
        }
    }
}
