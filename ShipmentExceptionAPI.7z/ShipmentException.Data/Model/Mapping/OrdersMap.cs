﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ShipmentException.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.Data.Model.Mapping
{
    public class OrdersMap : IEntityTypeConfiguration<Orders>
    {
        public void Configure(EntityTypeBuilder<Orders> builder)
        {
            builder.ToTable("orders");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createdby)
                        .IsRequired()
                        .HasColumnName("createdby")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Createddate)
                        .HasColumnName("createddate")
                        .HasColumnType("datetime");

            builder.Property(e => e.Gradedescription)
                        .HasColumnName("gradedescription")
                        .HasMaxLength(500)
                        .IsUnicode(false);

            builder.Property(e => e.Indicator)
                        .IsRequired()
                        .HasColumnName("indicator")
                        .HasMaxLength(20)
                        .IsUnicode(false);

            builder.Property(e => e.Isactive)
                        .IsRequired()
                        .HasColumnName("isactive")
                        .HasDefaultValueSql("((1))");

            builder.Property(e => e.Lineitemnumber)
                        .IsRequired()
                        .HasColumnName("lineitemnumber")
                        .HasMaxLength(10)
                        .IsUnicode(false);

            builder.Property(e => e.Materialnumber)
                        .HasColumnName("materialnumber")
                        .HasMaxLength(50)
                        .IsUnicode(false);

            builder.Property(e => e.Message)
                        .HasColumnName("message")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Ordernumber)
                        .IsRequired()
                        .HasColumnName("ordernumber")
                        .HasMaxLength(20)
                        .IsUnicode(false);

            builder.Property(e => e.Shippingfacilityname)
                        .HasColumnName("shippingfacilityname")
                        .HasMaxLength(50)
                        .IsUnicode(false);

            builder.Property(e => e.Shippingfacilitynumber)
                        .HasColumnName("shippingfacilitynumber")
                        .HasMaxLength(10)
                        .IsUnicode(false);

            builder.Property(e => e.Shiptocity)
                        .HasColumnName("shiptocity")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Shiptocustomername)
                        .HasColumnName("shiptocustomername")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Shiptoid)
                        .HasColumnName("shiptoid")
                        .HasMaxLength(20)
                        .IsUnicode(false);

            builder.Property(e => e.Shiptostate)
                        .HasColumnName("shiptostate")
                        .HasMaxLength(20)
                        .IsUnicode(false);

            builder.Property(e => e.Soldtocustomername)
                        .HasColumnName("soldtocustomername")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Soldtoid)
                        .HasColumnName("soldtoid")
                        .HasMaxLength(20)
                        .IsUnicode(false);

            builder.Property(e => e.Updatedby)
                        .HasColumnName("updatedby")
                        .HasMaxLength(200)
                        .IsUnicode(false);

            builder.Property(e => e.Updateddate)
                        .HasColumnName("updateddate")
                        .HasColumnType("datetime");
        }
    }
}
