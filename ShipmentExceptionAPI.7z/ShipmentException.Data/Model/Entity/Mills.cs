﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Mills
    {
        public Mills()
        {
            Mailinglist = new HashSet<Mailinglist>();
        }

        public int Id { get; set; }
        public string Millnumber { get; set; }
        public string Millname { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddatetime { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddatetime { get; set; }

        public virtual ICollection<Mailinglist> Mailinglist { get; set; }
    }
}
