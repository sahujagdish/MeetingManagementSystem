﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Shipmentexception
    {
        public Shipmentexception()
        {
            Shipmentdetails = new HashSet<Shipmentdetails>();
        }

        public int Id { get; set; }
        public string ExceptionNumber { get; set; }
        public string Status { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Updateddate { get; set; }
        public bool? Isactive { get; set; }

        public virtual ICollection<Shipmentdetails> Shipmentdetails { get; set; }
    }
}
