﻿using System;
using System.Collections.Generic;

namespace ShipmentException.Data.Model.Entity
{
    public partial class Orders
    {
        public Orders()
        {
            Shipmentordermapping = new HashSet<Shipmentordermapping>();
        }

        public int Id { get; set; }
        public string Ordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public string Indicator { get; set; }
        public string Message { get; set; }
        public string Materialnumber { get; set; }
        public string Gradedescription { get; set; }
        public string Shippingfacilitynumber { get; set; }
        public string Shippingfacilityname { get; set; }
        public string Soldtoid { get; set; }
        public string Soldtocustomername { get; set; }
        public string Shiptoid { get; set; }
        public string Shiptocustomername { get; set; }
        public string Shiptocity { get; set; }
        public string Shiptostate { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Updateddate { get; set; }
        public bool? Isactive { get; set; }

        public virtual ICollection<Shipmentordermapping> Shipmentordermapping { get; set; }
    }
}
