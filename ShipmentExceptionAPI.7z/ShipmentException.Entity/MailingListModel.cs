﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.BusinessModel
{
   public class MailingListModel : BaseModel
    {
        public int Id { get; set; }
        public int MillId { get; set; }
        public string Millnumber { get; set; }
        public string Millname { get; set; }
        public int OrdertypeId { get; set; }
        public string Ordertype { get; set; }
        public string Planningteamdl { get; set; }
        public string Executionteamdl { get; set; }

    }
}
