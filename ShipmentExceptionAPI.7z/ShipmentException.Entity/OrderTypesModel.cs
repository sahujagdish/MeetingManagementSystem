﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.BusinessModel
{
    public class OrderTypesModel:BaseModel
    {        
        public int OrdertypeId { get; set; }
        public string Ordertype { get; set; }
    }
}
