﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.BusinessModel
{
    public class CommonModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
