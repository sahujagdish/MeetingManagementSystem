﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ShipmentException.BusinessModel
{
    public class BaseModel
    {
        public string Createdby { get; set; }
        public DateTime Createddatetime { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddatetime { get; set; }
    }
}
