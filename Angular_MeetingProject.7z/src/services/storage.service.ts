import { Injectable } from '@angular/core';
import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';

@Injectable({
  providedIn: 'root'
})

export class StorageService {

  constructor(public local: LocalStorageService, public session: SessionStorageService) { }
 
    $LocalStorageSet(KEY: string, value:any ) {
        this.local.set(KEY, value, 1, 'd');
    }

    $LocalStorageGet(KEY) {
       return this.local.get(KEY);
    }

    $LocalStorageRemove(KEY:string) {
      this.local.remove(KEY);
    }
 
    $LocalStorageClear() {
        this.local.clear();
    }

    $SessionStorageSet(KEY: string, value:any ) {
      this.session.set(KEY, value, 30, 'm');
    }

    $SessionStorageGet(KEY) {
      return this.session.get(KEY);
    }

    $SessionStorageRemove(KEY:string) {
        this.session.remove(KEY);
    }

    $SessionStorageClear() {
      this.session.clear();
    }
}
