import { Component } from '@angular/core';

@Component({
  selector: 'app-home-layout',
  template: `
  <header></header>    
  <router-outlet ></router-outlet>
  <footerBar></footerBar>
  `,
  styles: []
})
export class HomeLayoutComponent {}
