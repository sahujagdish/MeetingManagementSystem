import { OnInit, Component,  Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { StorageService } from '../../services/storage.service';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../../security/auth.service';
import { AlertService } from '../../services/alert.service';
import { SharedService } from '../../services/shared.service'; 

@Component({
    selector: 'app-login',
    templateUrl: './applogin.component.html'
})

export class AppLoginComponent implements OnInit {
    private route: ActivatedRoute;
    myForm = new FormGroup({
        Username: new FormControl('admin'),
        Password: new FormControl('admin')
    });

    constructor(  private router: Router, private _sharedService: SharedService, 
        private authService: AuthService, private alertService: AlertService, private storage: StorageService) {
       
        
    }

    ngOnInit() {
       
    }

    loadMainScreenInfo() {

        let invalidfield : String = '';
        if (this.myForm.invalid) {
            debugger;
            Object.keys(this.myForm.controls).forEach((key) => {
                debugger;
               if(this.myForm.get(key).invalid == true){
                    if(invalidfield == ''){
                        invalidfield = "Please enter " +  key.charAt(0).toUpperCase() + key.substr(1).toLowerCase()+ " </br> ";   
                    } else {
                        invalidfield += "Please specify " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + " </br> ";
                    }                 
               }
            });
            this.alertService.showError(invalidfield);
            return;
        }

     this.storage.$SessionStorageSet('globalAuth',null);
     this.authService.login(this.myForm.value);
        
    }
}



