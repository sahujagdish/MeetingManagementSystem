import { OnInit, OnChanges, Component, Input, Output, EventEmitter, ViewEncapsulation} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../../services/shared.service'; 
import { MeetingService } from '../../services/meeting.service'; 
import { StorageService } from '../../services/storage.service';

@Component({   
    selector: 'viewDetails',    
    templateUrl: './viewDetails.component.html', 
    encapsulation: ViewEncapsulation.None,
})

export class ViewDetailComponent implements OnInit{

    items:any;
    dnp:[];
    ov:any;
    selectedRule:any = "0";
    selectedProduct:any = "0";
    p: number = 1;
    pagesize:any = "5";
    @Output() pageChange: EventEmitter<number>;

    constructor(private _sharedService: SharedService, private storage: StorageService, private router:Router, private activerouter: ActivatedRoute, private meetingService:MeetingService) { 
        
    }   

    ngOnInit() {        
        this.GetCalendar();
    }
    
    GetCalendar(){
        this.meetingService.getCalendar().subscribe((data : any[]) => {   
            this.items = data;
        });
    }

    MeetingDelete(id: any){ 
        var meet = confirm("Are you sure. You want to delete the record?");
        if (id != null) {            
            var bareartoken = this.storage.$SessionStorageGet('globalAuth');                 
            bareartoken.Username;            
            let retvalue = this.meetingService.MeetingDelete(id,bareartoken.Username);
            debugger;
            retvalue.then((value:any) => {
                alert("Record deleted successfully");
                this.GetCalendar();
            }).catch((value:any) => {
                alert("Error deleteing record !!!");
            });
        }
    }

    EditMeeting(id:any){       
        this.router.navigate(['AddUpdateMeet',id]); 
    }   
   
}


