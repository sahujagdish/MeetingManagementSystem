import { NgModule } from '@angular/core'; 
import { AdminRoutingModule } from './admin.route'; 
import { accessrightsComponent } from './accessrights.component'; 
import { userroleComponent } from './userrole.component'; 

@NgModule({
  imports: [    
    AdminRoutingModule 
  ],
  declarations:[
    userroleComponent,
    accessrightsComponent
  ]
})
export class adminModule { 
  
}
